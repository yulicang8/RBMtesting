"use strict";
var GameBubbleConfig = {
  minRadius: 16,
  maxRadius: 30,
  minDist: 30,
  param1: 20,
  param2: 26,

  // Chain length that earns a pop, and a cap so a frame full of false circles
  // cannot turn into a long burst of taps mid-chain.
  minChainForPop: 4,
  maxTaps: 4,
  tapDuring: 10
};
var Page = {

  TodayMissions: {
    name: 'TodayMissions',
    colors: [
      {x: 764, y: 445, r: 248, g: 190, b: 15, match: true, threshold: 80},
      {x: 781, y: 436, r: 165, g: 92, b: 63, match: true, threshold: 80},
      {x: 823, y: 445, r: 248, g: 249, b: 249, match: true, threshold: 80},
      {x: 554, y: 444, r: 45, g: 111, b: 142, match: true, threshold: 80},
      {x: 550, y: 1421, r: 33, g: 196, b: 231, match: true, threshold: 80},
      {x: 593, y: 1423, r: 240, g: 175, b: 8, match: true, threshold: 80},
      {x: 176, y: 1658, r: 238, g: 172, b: 8, match: true, threshold: 80},
      {x: 55, y: 1649, r: 238, g: 172, b: 8, match: true, threshold: 80},
      {x: 25, y: 1655, r: 8, g: 16, b: 26, match: true, threshold: 80}
    ],
    back: {x: 176, y: 1662},
    next: {x: 176, y: 1662}
  },
  TodayMission: {
    name: 'TodayMission',
    colors: [
      {x: 540, y: 1480, r: 238, g: 181, b: 12 , match: true, threshold: 80},
      {x: 975, y: 500, r: 161, g: 224, b: 231, match: true, threshold: 80},
      {x: 554, y: 1332, r: 24 , g: 189, b: 219, match: true, threshold: 80}
    ],
    back: {x: 558, y: 1473},
    next: {x: 558, y: 1473}
  },
  ScorePage: {
    name: 'ScorePage',
    colors: [
      {x: 302, y: 1581, r: 235, g: 184, b: 7  , match: true, threshold: 80},
      {x: 777, y: 1588, r: 248, g: 142, b: 20 , match: true, threshold: 80},
      {x: 774, y: 500, r: 243, g: 248, b: 242, match: true, threshold: 80}
    ],
    back: {x: 309, y: 1653},
    next: {x: 784, y: 1653}
  },
  ProfilePageJp: {
    name: 'ProfilePage',
    colors: [
      {x: 540, y: 1592, r: 246, g: 135, b:  17, match: true, threshold: 80}, // top of the start button
      {x: 187, y: 1599, r: 240, g: 218, b:  72, match: true, threshold: 80}, // top of the card button
      {x: 799, y: 1653, r: 232, g: 170, b:   7, match: true, threshold: 80}, // left of the myTsum button
      {x: 698, y:  464, r: 244, g: 249, b: 243, match: true, threshold: 80}, // above the ranking title
      {x:  34, y: 1004, r: 247, g: 178, b:   8, match: true, threshold: 80}, // left home tab button
      {x:  6, y: 1120, r:  46, g: 135, b: 232, match: true, threshold: 80}, // left ranking tab button
      {x:  6, y: 1270, r:  44, g: 134, b: 233, match: true, threshold: 80}  // left square tab button
    ],
    back: {x: 31, y: 1126},
    next: {x: 31, y: 1126},
    tsums: {x: 900, y: 1653}
  },
  ProfilePageIntl: {
    name: 'ProfilePage',
    colors: [
      {x: 540, y: 1592, r: 246, g: 135, b:  17, match: true, threshold: 80}, // top of the start button
      {x: 187, y: 1599, r: 240, g: 218, b:  72, match: true, threshold: 80}, // top of the card button
      {x: 799, y: 1653, r: 232, g: 170, b:   7, match: true, threshold: 80}, // left of the myTsum button
      {x: 698, y:  464, r: 244, g: 249, b: 243, match: true, threshold: 80}, // above the ranking title
      {x:  34, y: 1004, r: 247, g: 178, b:   8, match: true, threshold: 80}, // left home tab button
      {x:   6, y: 1120, r:  46, g: 135, b: 232, match: true, threshold: 80}, // left ranking tab button
      {x:   6, y: 1270, r:  52, g:  98, b: 143, match: true, threshold: 80}  // left border where in JP left square tab button is
    ],
    back: {x: 31, y: 1126},
    next: {x: 31, y: 1126},
    tsums: {x: 900, y: 1653}
  },
  SquarePage: {
    name: 'SquarePage',
    colors: [
      {x: 540, y: 1592, r: 246, g: 135, b:  17, match: true, threshold: 80}, // top of the start button
      {x: 187, y: 1599, r: 240, g: 218, b:  72, match: true, threshold: 80}, // top of the card button
      {x: 799, y: 1653, r: 232, g: 170, b:   7, match: true, threshold: 80}, // left of the myTsum button
      {x:  18, y:  994, r:  46, g: 135, b: 234, match: true, threshold: 80}, // left home tab button
      {x:  16, y: 1120, r:  46, g: 135, b: 232, match: true, threshold: 80}, // left ranking tab button
      {x:  34, y: 1270, r: 247, g: 175, b:   8, match: true, threshold: 80}  // left square tab button
    ],
    back: {x: 31, y: 1126},
    next: {x: 31, y: 1126}
  },
  FriendPage: {
    name: 'FriendPage',
    colors: [
      {x: 540, y: 1592, r: 246, g: 135, b: 17 , match: true, threshold: 80}, // top of the start button
      {x: 187, y: 1599, r: 240, g: 218, b: 72 , match: true, threshold: 80}, // top of the card button
      {x: 799, y: 1653, r: 232, g: 170, b: 7  , match: true, threshold: 80}, // left of the myTsum button
      {x: 698, y: 464, r: 244, g: 249, b: 243, match: true, threshold: 80}, // left top of the ranking time
      {x: 960, y: 430, r: 24, g: 192, b: 231, match: true, threshold: 80}           // right bottom next to the mailbox icon
    ],
    back: {x: 547, y: 1653},
    next: {x: 547, y: 1653},
    tsums: {x: 900, y: 1653}
  },
  FriendPage2: {
    name: 'FriendPage',
    colors: [
      {x: 540, y: 1649, r: 175, g: 188, b: 197, match: true, threshold: 80}, // center of the Tsum Hades
      {x: 187, y: 1599, r: 240, g: 218, b: 72 , match: true, threshold: 80}, // top of the card button
      {x: 799, y: 1653, r: 232, g: 170, b: 7  , match: true, threshold: 80}, // left of the myTsum button
      {x: 698, y: 464, r: 244, g: 249, b: 243, match: true, threshold: 80}, // left top of the ranking time
      {x: 960, y: 430, r: 24, g: 192, b: 231, match: true, threshold: 80}           // right bottom next to the mailbox icon
    ],
    back: {x: 547, y: 1653},
    next: {x: 547, y: 1653},
    tsums: {x: 900, y: 1653}
  },
  FriendPage3: {
    name: 'FriendPage',
    colors: [
      {x: 540, y: 1649, r: 203, g: 192, b: 237, match: true, threshold: 80}, // center of the Tsum Ursula
      {x: 187, y: 1599, r: 240, g: 218, b: 72 , match: true, threshold: 80}, // top of the card button
      {x: 799, y: 1653, r: 232, g: 170, b: 7  , match: true, threshold: 80}, // left of the myTsum button
      {x: 698, y: 464, r: 244, g: 249, b: 243, match: true, threshold: 80}, // left top of the ranking time
      {x: 960, y: 430, r: 24, g: 192, b: 231, match: true, threshold: 80}           // right bottom next to the mailbox icon
    ],
    back: {x: 547, y: 1653},
    next: {x: 547, y: 1653},
    tsums: {x: 900, y: 1653}
  },
  FriendPage4: {
    name: 'FriendPage',
    colors: [
      {x: 540, y: 1649, r: 79 , g: 89 , b: 94 , match: true, threshold: 80}, // center of the Tsum Maleficentd
      {x: 187, y: 1599, r: 240, g: 218, b: 72 , match: true, threshold: 80}, // top of the card button
      {x: 799, y: 1653, r: 232, g: 170, b: 7  , match: true, threshold: 80}, // left of the myTsum button
      {x: 698, y: 464, r: 244, g: 249, b: 243, match: true, threshold: 80}, // left top of the ranking time
      {x: 960, y: 430, r: 24, g: 192, b: 231, match: true, threshold: 80}           // right bottom next to the mailbox icon
    ],
    back: {x: 547, y: 1653},
    next: {x: 547, y: 1653},
    tsums: {x: 900, y: 1653}
  },
  GiftHeart: {
    name: 'GiftHeart',
    colors: [
      {x: 216, y: 1084, r: 233, g: 172, b: 6  , match: true, threshold: 80},
      {x: 673, y: 1080, r: 235, g: 174, b: 8  , match: true, threshold: 80},
      {x: 468, y: 803, r: 214, g: 61 , b: 143, match: true, threshold: 100},
      {x: 572, y: 561, r: 30 , g: 193, b: 224, match: true, threshold: 80},
      {x: 583, y: 1195, r: 28 , g: 186, b: 221, match: true, threshold: 80}
    ],
    back: {x: 774, y: 1095},
    next: {x: 320, y: 1091}
  },
  MailBox: {
    name: 'MailBox',
    colors: [
      {x: 738, y: 414, r: 240, g: 245, b: 239, match: true, threshold: 80},
      {x: 550, y: 1581, r: 238, g: 187, b: 10 , match: true, threshold: 80},
      {x: 604, y: 1419, r: 234, g: 171, b: 6  , match: true, threshold: 80}
    ],
    back: {x: 561, y: 1653},
    next: {x: 561, y: 1653}
  },
  MailBox2: {
    name: 'MailBox',
    colors: [
      {x: 738, y: 414, r: 240, g: 245, b: 239, match: true, threshold: 80},
      {x: 550, y: 1581, r: 238, g: 187, b: 10 , match: true, threshold: 80},
      {x: 619, y: 1426, r: 19 , g: 137, b: 175, match: true, threshold: 80}
    ],
    back: {x: 561, y: 1653},
    next: {x: 561, y: 1653}
  },
  ReceiveHeart: {
    name: 'ReceiveHeart',
    colors: [
      {x: 208, y: 1080, r: 233, g: 172, b: 6  , match: true, threshold: 80},
      {x: 662, y: 1080, r: 232, g: 171, b: 5  , match: true, threshold: 80},
      {x: 561, y: 554, r: 28 , g: 191, b: 222, match: true, threshold: 80},
      {x: 565, y: 1210, r: 30 , g: 195, b: 225, match: true, threshold: 80},
      {x: 334, y: 817, r: 213, g: 62 , b: 143, match: true, threshold: 90},
      {x: 586, y: 821, r: 248, g: 249, b: 51 , match: true, threshold: 100}
    ],
    back: {x: 774, y: 1095},
    next: {x: 320, y: 1091}
  },
  Received: {
    name: 'Received',
    colors: [
      {x: 799, y: 716, r: 30, g: 188, b: 223, match: true, threshold: 80},
      {x: 806, y: 889, r: 45, g: 80 , b: 122, match: true, threshold: 80},
      {x: 799, y: 1048, r: 27, g: 188, b: 217, match: true, threshold: 80}
    ],
    back: {x: 774, y: 1095},
    next: {x: 320, y: 1091}
  },
  Received2: {
    name: 'Received',
    colors: [
      {x: 799, y: 716, r: 30, g: 188, b: 223, match: true, threshold: 80},
      {x: 889, y: 824, r: 40, g: 72 , b: 111, match: true, threshold: 80},
      {x: 799, y: 1048, r: 27, g: 188, b: 217, match: true, threshold: 80}
    ],
    back: {x: 774, y: 1095},
    next: {x: 320, y: 1091}
  },
  StartPage: {
    name: 'StartPage',
    colors: [
      {x: 752, y: 471, r: 244, g: 249, b: 243, match: true, threshold: 80},
      {x: 856, y: 1430, r: 30 , g: 193, b: 224, match: true, threshold: 80},
      {x: 169, y: 1581, r: 239, g: 188, b: 11 , match: true, threshold: 80},
      {x: 547, y: 1581, r: 235, g: 118, b: 134, match: true, threshold: 80},
      {x: 792, y: 1660, r: 234, g: 171, b: 8  , match: true, threshold: 100}
    ],
    back: {x: 190, y: 1646},
    next: {x: 558, y: 1635},
    tsums: {x: 900, y: 1653}
  },
  StartPage2: {
    name: 'StartPage',
    colors: [
      {x: 820,  y: 515, r: 245, g: 250, b: 244, match: true, threshold: 80},
      {x: 954,  y: 1426, r: 31 , g: 190, b: 220, match: true, threshold: 80},
      {x: 180,  y: 1584, r: 235, g: 182, b: 8  , match: true, threshold: 80},
      {x: 540,  y: 1584, r: 238, g: 115, b: 133, match: true, threshold: 80},
      {x: 1011, y: 1675, r: 229, g: 166, b: 11 , match: true, threshold: 100}
    ],
    back: {x: 190, y: 1646},
    next: {x: 558, y: 1635}
  },
  StartPage3: {
    name: 'StartPage',
    colors: [
      {x: 400,  y: 1672, r: 245, g: 85, b: 115, match: true, threshold: 80},
      {x: 680,  y: 1672, r: 245, g: 85, b: 115, match: true, threshold: 80},
      {x: 540,  y: 1722, r: 235, g: 70, b: 90 , match: true, threshold: 80}
    ],
    back: {x: 190, y: 1646},
    next: {x: 558, y: 1635}
  },
  TsumsPage: {
    name: 'TsumsPage',
    colors: [
      {x: 27, y: 901, r: 197, g: 243, b: 254, match: true, threshold: 80},    // left of "Tsum Tsum Collection" title bar
      {x: 436, y: 902, r: 247, g: 247, b: 247, match: true, threshold: 80},   // middle of "Tsum Tsum Collection" title bar
      {x: 713, y: 900, r: 247, g: 187, b: 16, match: true, threshold: 80},   // right of "Tsum Tsum Collection" title bar (short before "Level Lock")
      {x: 1030, y: 900, r: 249, g: 190, b: 19, match: true, threshold: 80}    // yellow "order" button

    ],
    lockIcons: [
      {x: 196, y: 1195, r: 239, g: 247, b: 255},
      {x: 430, y: 1195, r: 239, g: 247, b: 255},
      {x: 665, y: 1195, r: 239, g: 247, b: 255},
      {x: 900, y: 1195, r: 239, g: 247, b: 255},
      {x: 196, y: 1450, r: 239, g: 247, b: 255},
      {x: 430, y: 1450, r: 239, g: 247, b: 255},
      {x: 665, y: 1450, r: 239, g: 247, b: 255},
      {x: 900, y: 1450, r: 239, g: 247, b: 255}
    ],
    back: {x: 176, y: 1592},
    next: {x: 176, y: 1592},
    store: {x: 910, y: 1592}
  },
  TsumTsum2025StorePage: {
    name: 'TsumTsumStorePage',
    colors: [
      {x: 30, y: 910, r: 16, g: 53, b: 93, match: true, threshold: 30},
      {x: 60, y: 910, r: 233, g: 171, b: 8, match: true, threshold: 30},
      {x: 520, y: 910, r: 237, g: 174, b: 8, match: true, threshold: 30},
      {x: 545, y: 840, r: 22, g: 65, b: 107, match: true, threshold: 30},
      {x: 570, y: 910, r: 29, g: 85, b: 159, match: true, threshold: 30},
      {x: 10, y: 955, r: 37, g: 71, b: 115, match: true, threshold: 30},
      {x: 170, y: 1490, r: 48, g: 81, b: 130, match: true, threshold: 30},
      {x: 170, y: 1515, r: 8, g: 164, b: 213, match: true, threshold: 30},
      {x: 170, y: 1570, r: 247, g: 194, b: 16, match: true, threshold: 30}
    ],
    back: {x: 190, y: 1650},
    next: {x: 1000, y: 690, r: 238, g: 172, b: 8}
  },
  ConfirmPurchaseBoxPage: {
    name: 'ConfirmPurchasePage',
    colors: [
      {x: 208, y: 1070, r: 247, g: 176, b: 8, match: true, threshold: 30},  // left of Cancel button
      {x: 420, y: 1070, r: 247, g: 176, b: 8, match: true, threshold: 30},  // right of Cancel button
      {x: 540, y: 1070, r: 54, g: 93, b: 146, match: true, threshold: 30},  // between buttons
      {x: 650, y: 1070, r: 247, g: 176, b: 8, match: true, threshold: 30},  // left of OK button
      {x: 880, y: 1070, r: 247, g: 176, b: 8, match: true, threshold: 30},  // right of OK button
      {x: 948, y: 1066, r: 33, g: 69, b: 107, match: true, threshold: 30},  // right next to OK button
      {x: 805, y: 1265, r: 239, g: 167, b: 8, match: true, threshold: 50}   // left of List button
    ],
    back: {x: 310, y: 1070},  // Cancel button
    next: {x: 760, y: 1070}   // OK button
  },
  Confirm2025PurchaseBoxPage: {
    name: 'ConfirmPurchasePage',
    colors: [
      {x: 208, y: 1070, r: 247, g: 186, b:   8, match: true, threshold: 30},  // left of Cancel button
      {x: 420, y: 1070, r: 247, g: 184, b:   8, match: true, threshold: 30},  // right of Cancel button
      {x: 540, y: 1070, r:  54, g:  90, b: 141, match: true, threshold: 30},  // between buttons
      {x: 650, y: 1070, r: 247, g: 190, b:   8, match: true, threshold: 30},  // left of OK button
      {x: 880, y: 1070, r: 247, g: 191, b:  14, match: true, threshold: 30},  // right of OK button
      {x: 948, y: 1066, r:  40, g:  70, b: 113, match: true, threshold: 30},  // right next to OK button
      {x: 785, y: 1320, r: 238, g: 171, b:   8, match: true, threshold: 50}   // left of List button
    ],
    back: {x: 310, y: 1070},  // Cancel button
    next: {x: 760, y: 1070}   // OK button
  },
  ConfirmPurchaseCapsulePage: {
    name: 'ConfirmPurchasePage',
    colors: [
      {x: 200, y: 1444, r: 247, g: 178, b: 8, match: true, threshold: 30},  // left of Cancel button
      {x: 426, y: 1444, r: 247, g: 178, b: 8, match: true, threshold: 30},  // right of Cancel button
      {x: 540, y: 1444, r: 54, g: 93, b: 146, match: true, threshold: 30},  // between buttons
      {x: 660, y: 1444, r: 247, g: 174, b: 8, match: true, threshold: 30},  // left of OK button
      {x: 860, y: 1444, r: 247, g: 178, b: 8, match: true, threshold: 30},  // right of OK button
      {x: 940, y: 1444, r: 33, g: 65, b: 107, match: true, threshold: 30},  // right next to OK button
      {x: 416, y: 790, r: 239, g: 28, b: 49, match: true, threshold: 30}    // red top of big pickup capsule image
    ],
    back: {x: 320, y: 1444},  // Cancel button
    next: {x: 766, y: 1444}   // OK button
  },
  Confirm2025PurchaseCapsulePage: {
    name: 'ConfirmPurchasePage',
    colors: [
      {x: 200, y: 1464, r: 247, g: 178, b: 8, match: true, threshold: 30},      // left of Cancel button
      {x: 426, y: 1464, r: 247, g: 178, b: 8, match: true, threshold: 30},      // right of Cancel button
      {x: 540, y: 1464, r: 54, g: 93, b: 146, match: true, threshold: 30},      // between buttons
      {x: 660, y: 1464, r: 247, g: 174, b: 8, match: true, threshold: 30},      // left of OK button
      {x: 860, y: 1464, r: 247, g: 178, b: 8, match: true, threshold: 30},      // right of OK button
      {x: 940, y: 1464, r: 33, g: 65, b: 107, match: true, threshold: 30},      // right next to OK button
      {x: 836, y: 1152, r: 255, g: 255, b: 255, match: true, threshold: 30},    // lower left of slash in "15/15"
      {x: 860, y: 1081, r: 255, g: 255, b: 255, match: true, threshold: 30},    // upper right of slash in "15/15"
      {x: 860, y: 1152, r: 48, g: 81, b: 127, match: true, threshold: 30}       // blue area under slash in "15/15"
    ],
    back: {x: 320, y: 1464},  // Cancel button
    next: {x: 766, y: 1464}   // OK button
  },
  TapOpenPageBox: {
    name: 'TapOpenPage',
    colors: [
      {x: 641, y: 328, r: 255, g: 255, b: 231, match: true, threshold: 30},
      {x: 641, y: 243, r: 255, g: 255, b: 247, match: true, threshold: 30},
      {x: 180, y: 520, r: 247, g: 182, b: 189, match: true, threshold: 30},
      {x: 899, y: 777, r: 140, g: 121, b: 156, match: true, threshold: 30},
      {x: 68, y: 1265, r: 33, g: 73, b: 107, match: true, threshold: 30},
      {x: 964, y: 1265, r: 33, g: 73, b: 115, match: true, threshold: 30},
      {x: 534, y: 1840, r: 33, g: 190, b: 231, match: true, threshold: 30}
    ],
    back: {x: 500, y: 1600},
    next: {x: 500, y: 1600}
  },
  TapOpenPageCapsule: {
    name: 'TapOpenPage',
    colors: [
      {x: 70, y: 560, r: 24, g: 85, b: 132, match: true, threshold: 30},
      {x: 899, y: 777, r: 137, g: 117, b: 148, match: true, threshold: 30},
      {x: 68, y: 1265, r: 33, g: 73, b: 107, match: true, threshold: 30},
      {x: 964, y: 1265, r: 33, g: 73, b: 115, match: true, threshold: 30},
      {x: 405, y: 1397, r: 255, g: 255, b: 255, match: true, threshold: 30}, // T from "TAP!"
      {x: 546, y: 1429, r: 255, g: 255, b: 255, match: true, threshold: 30}, // A from "TAP!"
      {x: 664, y: 1407, r: 255, g: 255, b: 255, match: true, threshold: 30}, // P from "TAP!"
      {x: 709, y: 1381, r: 255, g: 255, b: 255, match: true, threshold: 30} // ! from "TAP!"
    ],
    back: {x: 500, y: 1600},
    next: {x: 500, y: 1600}
  },
  TapOpenPageCapsuleDeprecated: {
    name: 'TapOpenPageDeprecated',
    colors: [
      {x: 620, y: 328, r: 205, g: 13, b: 34, match: true, threshold: 30},
      {x: 641, y: 243, r: 146, g: 0, b: 0, match: true, threshold: 30},
      {x: 70, y: 560, r: 24, g: 85, b: 132, match: true, threshold: 30},
      {x: 899, y: 777, r: 137, g: 117, b: 148, match: true, threshold: 30},
      {x: 68, y: 1265, r: 33, g: 73, b: 107, match: true, threshold: 30},
      {x: 964, y: 1265, r: 33, g: 73, b: 115, match: true, threshold: 30},
      {x: 534, y: 1840, r: 33, g: 190, b: 231, match: true, threshold: 30}
    ],
    back: {x: 500, y: 1600},
    next: {x: 500, y: 1600}
  },
  BoxPurchasedPage: {
    name: 'BoxPurchasedPage',
    colors: [
      {x: 156, y: 1077, r: 33, g: 195, b: 231, match: true, threshold: 30},
      {x: 48, y: 998, r: 24, g: 52, b: 82, match: true, threshold: 30},
      {x: 131, y: 1134, r: 33, g: 65, b: 107, match: true, threshold: 30},
      {x: 928, y: 1077, r: 33, g: 203, b: 239, match: true, threshold: 30},
      {x: 923, y: 1183, r: 33, g: 65, b: 107, match: true, threshold: 30},
      {x: 904, y: 1396, r: 33, g: 199, b: 239, match: true, threshold: 30},
      {x: 389, y: 1634, r: 247, g: 174, b: 8, match: true, threshold: 30},
      {x: 279, y: 1627, r: 41, g: 77, b: 115, match: true, threshold: 30},
      {x: 525, y: 1823, r: 24, g: 158, b: 189, match: true, threshold: 30}
    ],
    back: {x: 550, y: 1630},  // Close button
    next: {x: 550, y: 1630}   // Close button
  },
  PremiumPlusBoxPurchasedPage: {
    name: 'BoxPurchasedPage',
    colors: [
      {x: 156, y: 1077, r: 33, g: 195, b: 231, match: true, threshold: 30},
      {x: 48, y: 998, r: 33, g: 66, b: 99, match: true, threshold: 30},
      {x: 131, y: 1137, r: 33, g: 62, b: 101, match: true, threshold: 30},
      {x: 928, y: 1075, r: 33, g: 203, b: 236, match: true, threshold: 30},
      {x: 922, y: 1184, r: 33, g: 65, b: 107, match: true, threshold: 30},
      {x: 904, y: 1396, r: 33, g: 199, b: 239, match: true, threshold: 30},
      {x: 389, y: 1634, r: 238, g: 174, b: 8, match: true, threshold: 30},
      {x: 280, y: 1626, r: 63, g: 103, b: 147, match: true, threshold: 30},
      {x: 525, y: 1823, r: 40, g: 210, b: 247, match: true, threshold: 30}
    ],
    back: {x: 550, y: 1630},  // Close button
    next: {x: 550, y: 1630}   // Close button
  },
  GamePause: {
    name: 'GamePause',
    colors: [
      {x: 165, y: 1077, r: 234, g: 173, b:   7, match: true, threshold: 80},
      {x: 586, y: 1080, r: 239, g: 174, b:   7, match: true, threshold: 80},
      {x: 367, y:  774, r:  24, g: 191, b: 225, match: true, threshold: 80},
      {x: 738, y:  612, r: 248, g: 244, b: 245, match: true, threshold: 80},
      {x: 550, y: 1336, r: 247, g: 185, b:   8, match: true, threshold: 80}
    ],
    back: {x: 331, y: 1080},
    next: {x: 561, y: 1422}
  },
  GamePlaying480x800: {
    name: 'GamePlaying',
    colors: [
      {x: 916, y: 198, r: 253, g: 216, b: 0, match: true, threshold: 80}, // above pause
      {x: 916, y: 318, r: 241, g: 161, b: 8, match: true, threshold: 80}, // below pause
      {x: 916, y: 1688, r: 242, g: 161, b: 8, match: true, threshold: 80} // below fan
    ],
    back: {x: 986, y: 273},
    next: {x: 986, y: 273}
  },
  GamePlayingLastSeconds: {
    name: 'GamePlaying',
    colors: [
      {x: 916, y: 198, r: 181, g: 207, b: 74, match: true, threshold: 80}, // above pause
      {x: 916, y: 318, r: 190, g: 174, b: 57, match: true, threshold: 80}, // below pause
      {x: 916, y: 1688, r: 181, g: 178, b: 74, match: true, threshold: 80} // below fan
    ],
    back: {x: 986, y: 273},
    next: {x: 986, y: 273}
  },
  GamePlaying: {
    name: 'GamePlaying',
    colors: [
      {x: 916, y: 198, r: 230, g: 200, b: 20, match: true, threshold: 80}, // above pause
      {x: 916, y: 318, r: 214, g: 191, b: 28, match: true, threshold: 80}, // below pause
      {x: 916, y: 1688, r: 214, g: 191, b: 28, match: true, threshold: 80} // below fan
    ],
    back: {x: 986, y: 273},
    next: {x: 986, y: 273}
  },
  GamePlaying2: {
    name: 'GamePlaying',
    colors: [
      {x: 980, y: 258, r: 190, g: 244, b: 70, match: true, threshold: 80}, // right of pause
      {x: 852, y: 258, r: 244, g: 197, b: 20, match: true, threshold: 80}, // left of pause
      {x: 916, y: 1688, r: 230, g: 150, b: 25, match: true, threshold: 80} // below fan
    ],
    back: {x: 986, y: 273},
    next: {x: 986, y: 273}
  },
  RootDetectionLdp1080p480dpiEn: {
    name: 'RootDetectionLdp1080p480dpiEn',
    colors: [
      {x: 80, y: 690, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 70, y: 680,  r: 255 , g: 255, b: 255, match: false, threshold: 25},
      {x: 1000, y: 1300, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 1010, y: 1310, r: 255 , g: 255, b: 255, match: false, threshold: 25}
    ],
    back: {x: 855, y: 1224},
    next: {x: 855, y: 1224},
    onDetect: switchToStartupMode
  },
  RootDetectionLdp1080p480dpiJp: {
    name: 'RootDetectionLdp1080p480dpiJp',
    colors: [
      {x: 80, y: 635, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 70, y: 625, r: 255 , g: 255, b: 255, match: false, threshold: 25},
      {x: 1000, y: 1360, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 1010, y: 1370, r: 255 , g: 255, b: 255, match: false, threshold: 25}
    ],
    back: {x: 850, y: 1280},
    next: {x: 850, y: 1280},
    onDetect: switchToStartupMode
  },
  RootDetectionLdp480x800x160dpiEn: {
    name: 'RootDetectionLdp480x800x160dpiEn',
    colors: [
      {x: 90, y: 780, r: 253 , g: 253, b: 253, match: true, threshold: 25},
      {x: 65, y: 745, r: 255 , g: 255, b: 255, match: false, threshold: 25},
      {x: 990, y: 1190, r: 252 , g: 252, b: 252, match: true, threshold: 25},
      {x: 1015, y: 1225, r: 255 , g: 255, b: 255, match: false, threshold: 25}
    ],
    back: {x: 885, y: 1135},
    next: {x: 885, y: 1135},
    onDetect: switchToStartupMode
  },
  RootDetectionNox1080p360dpiEn: {
    name: 'RootDetectionNox1080p360dpiEn',
    colors: [
      {x: 135, y: 795, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 125, y: 785, r: 255 , g: 255, b: 255, match: false, threshold: 25},
      {x: 945, y: 1170, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 955, y: 1180, r: 255 , g: 255, b: 255, match: false, threshold: 25}
    ],
    back: {x: 850, y: 1115},
    next: {x: 850, y: 1115},
    onDetect: switchToStartupMode
  },
  RootDetectionNox480x800x160dpiJp: {
    name: 'RootDetectionNox480x800x160dpiJp',
    colors: [
      {x: 85, y: 735, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 75, y: 725, r: 255 , g: 255, b: 255, match: false, threshold: 25},
      {x: 995, y: 1240, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 1005, y: 1250, r: 255 , g: 255, b: 255, match: false, threshold: 25}
    ],
    back: {x: 885, y: 1170},
    next: {x: 885, y: 1170},
    onDetect: switchToStartupMode
  },
  RootDetectionNox480x800x160dpiEn: {
    name: 'RootDetectionNox480x800x160dpiEn',
    colors: [
      {x: 85, y: 760, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 75, y: 750, r: 255 , g: 255, b: 255, match: false, threshold: 25},
      {x: 995, y: 1215, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 1005, y: 1225, r: 255 , g: 255, b: 255, match: false, threshold: 25}
    ],
    back: {x: 885, y: 1150},
    next: {x: 885, y: 1150},
    onDetect: switchToStartupMode
  },
  RootDetectionSamsungA20En: {
    name: 'RootDetectionSamsungA20En',
    colors: [
      {x: 60, y: 440, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 50, y: 440, r: 255 , g: 255, b: 255, match: false, threshold: 25},
      {x: 60, y: 430, r: 255 , g: 255, b: 255, match: false, threshold: 25},
      {x: 1020, y: 1310, r: 255 , g: 255, b: 255, match: true, threshold: 25},
      {x: 1020, y: 1320, r: 255 , g: 255, b: 255, match: false, threshold: 25},
      {x: 1010, y: 1325, r: 255 , g: 255, b: 255, match: false, threshold: 25}
    ],
    back: {x: 850, y: 1230},
    next: {x: 850, y: 1230},
    onDetect: switchToStartupMode
  },
  MagicalTime: {
    name: 'MagicalTime',
    colors: [
      {x: 817, y: 507, r: 244, g: 249, b: 243, match: true, threshold:  80},
      {x: 594, y: 857, r: 248, g: 102, b: 121, match: true, threshold: 100},
      {x: 208, y: 1217, r: 236, g: 175, b:   9, match: true, threshold:  80},
      {x: 662, y: 1213, r: 232, g: 171, b:   5, match: true, threshold:  80}
    ],
    back: {x: 381, y: 1221},
    next: {x: 856, y: 1221}
  },
  OutOfMedals: {
    name: 'OutOfMedals',
    colors: [
      {x: 127, y:  873, r:  74, g:  74, b:  74, match: true, threshold: 80},  // mickey left-side ear
      {x: 186, y:  898, r: 255, g: 213, b: 188, match: true, threshold: 80},  // mickey face
      {x: 865, y:  879, r: 247, g: 251, b: 255, match: true, threshold: 80},  // donald face
      {x: 474, y: 1065, r: 238, g: 174, b:   8, match: true, threshold: 80},  // left button
      {x: 540, y: 1070, r:  56, g:  91, b: 140, match: true, threshold: 80},  // blue between both buttons
      {x: 595, y: 1066, r: 238, g: 171, b:   8, match: true, threshold: 80}   // right button
    ],
    back: {x: 300, y: 1080},
    next: {x: 300, y: 1080}
  },
  NetworkDisable: {
    name: 'NetworkDisable',
    colors: [
      {x: 478, y: 1080, r: 236, g:  94, b: 116, match: true, threshold: 80},
      {x: 932, y: 1077, r: 232, g: 171, b:   5, match: true, threshold: 80}
    ],
    back: {x: 885, y: 1080},
    next: {x: 885, y: 1084}
  },
  NetworkTimeout: {
    name: 'NetworkTimeout',
    colors: [
      {x: 530, y: 590, r: 33, g: 197, b: 234, match: true, threshold: 80},
      {x: 530, y: 620, r: 59, g: 94, b: 148, match: true, threshold: 80},
      {x: 478, y: 1080, r: 232, g: 171, b: 5, match: true, threshold: 80},
      {x: 932, y: 1077, r: 232, g: 171, b: 5, match: true, threshold: 80},
      {x: 530, y: 1150, r: 59, g: 94, b: 148, match: true, threshold: 80},
      {x: 530, y: 1170, r: 33, g: 197, b: 234, match: true, threshold: 80}
    ],
    back: {x: 885, y: 1084},
    next: {x: 885, y: 1084}
  },
  FriendInfo: { // FriendInfo of Friend Page, SocailAccount of Setting Page
    name: 'FriendInfo',
    colors: [
      {x: 565, y: 576, r:  31, g: 190, b: 220, match: true, threshold: 80},
      {x: 547, y: 1195, r:  27, g: 192, b: 222, match: true, threshold: 80},
      {x: 554, y: 1332, r: 238, g: 186, b:  12, match: true, threshold: 80}
    ],
    back: {x: 576, y: 1408},
    next: {x: 576, y: 1408}
  },
  LevelUp: { // LevelUp and RankUp
    name: 'LevelUp',
    colors: [
      {x: 140, y: 1656, r: 233, g: 175, b: 6, match: true, threshold: 80}, // left of the close button
      {x: 450, y: 1656, r: 233, g: 175, b: 6, match: true, threshold: 80}, // right of the close button
      {x: 620, y: 1656, r: 233, g: 175, b: 6, match: true, threshold: 80}, // left of the share button
      {x: 930, y: 1656, r: 233, g: 175, b: 6, match: true, threshold: 80} // right of the share button
    ],
    back: {x: 300, y: 1660},
    next: {x: 300, y: 1660}
  },
  HighScore: {
    name: 'HighScore',
    colors: [
      {x: 576, y: 1325, r: 238, g: 187, b:  10, match: true, threshold: 80}, // top yellow of close button
      {x: 576, y: 1082, r:  33, g: 194, b: 231, match: true, threshold: 80}, // bottom light blue of highscore cell
      {x: 576, y:  762, r:  33, g: 194, b: 231, match: true, threshold: 80}, // top light blue of highscore cell
      {x: 576, y:  820, r:  64, g: 109, b: 171, match: true, threshold: 80}  // inner dark blue of highscore cell
    ],
    back: {x: 576, y: 1325},
    next: {x: 576, y: 1325}
  },
  ClosePage: { // including EventPage, MyInfo, SettingPage, others
    name: 'ClosePage', // the close button at center bottom
    colors: [
      {x: 540, y: 1588, r: 233, g: 180, b: 10, match: true, threshold: 80} // top right of the close button
    ],
    back: {x: 576, y: 1660},
    next: {x: 576, y: 1660}
  },
  // *** Following commented out because detection is way too unspecific and I don't know what it should detect.
  // InvitePage: {
  //   name: 'InvitePage', // the close button at left bottom
  //   colors: [
  //     {x: 180, y: 1592, r: 238, g: 180, b: 11, match: true, threshold: 80}
  //   ],
  //   back: {x: 176, y: 1592},
  //   next: {x: 176, y: 1592}
  // },
  ReceiveSkillTicket: {
    name: 'ReceiveSkillTicket',
    colors: [
      {x: 405, y: 806, r: 240, g: 155, b: 20, match: true, threshold: 80},
      {x: 488, y: 839, r: 244, g: 164, b: 23, match: true, threshold: 80},
      {x: 502, y: 821, r: 255, g: 255, b: 255, match: true, threshold: 40},
      {x: 390, y: 824, r: 58, g: 92, b: 142, match: true, threshold: 80},
      {x: 522, y: 812, r: 60, g: 95, b: 147, match: true, threshold: 80},
      {x: 874, y: 1098, r: 238, g: 174, b: 8, match: true, threshold: 80},
      {x: 198, y: 1095, r: 239, g: 174, b: 8, match: true, threshold: 80},
      {x: 160, y: 1545, r: 0, g: 4, b: 8, match: true, threshold: 80},
      {x: 526, y: 553, r: 33, g: 195, b: 231, match: true, threshold: 80}
    ],
    back: {x: 198, y: 1095},
    next: {x: 874, y: 1098}
  },
  ReceivePremiumTicket: {
    name: 'ReceivePremiumTicket',
    colors: [
      {x: 405, y: 806, r: 216, g: 20, b: 25, match: true, threshold: 80},
      {x: 488, y: 839, r: 208, g: 20, b: 23, match: true, threshold: 80},
      {x: 502, y: 821, r: 255, g: 247, b: 181, match: true, threshold: 40},
      {x: 390, y: 824, r: 58, g: 92, b: 142, match: true, threshold: 80},
      {x: 522, y: 812, r: 60, g: 95, b: 147, match: true, threshold: 80},
      {x: 874, y: 1098, r: 238, g: 174, b: 8, match: true, threshold: 80},
      {x: 198, y: 1095, r: 239, g: 174, b: 8, match: true, threshold: 80},
      {x: 160, y: 1545, r: 0, g: 4, b: 8, match: true, threshold: 80},
      {x: 526, y: 553, r: 33, g: 195, b: 231, match: true, threshold: 80}
    ],
    back: {x: 198, y: 1095},
    next: {x: 874, y: 1098}
  },
  ReceiveHeartWithoutCoins: {
    name: 'ReceiveHeartWithoutCoins',
    colors: [
      {x: 360, y: 570, r: 33, g: 198, b: 233, match: true, threshold: 30},
      {x: 400, y: 620, r: 61, g: 94, b: 147, match: true, threshold: 30},
      {x: 460, y: 820, r: 222, g: 61, b: 148, match: true, threshold: 30},
      {x: 420, y: 1100, r: 238, g: 174, b: 8, match: true, threshold: 30},
      {x: 860, y: 1100, r: 238, g: 174, b: 8, match: true, threshold: 30},
      {x: 540, y: 1100, r: 58, g: 94, b: 146, match: true, threshold: 30},
      {x: 550, y: 1600, r: 49, g: 36, b: 0, match: true, threshold: 30}
    ],
    back: {x: 420, y: 1100},
    next: {x: 860, y: 1100}
  },
  ExtraUpdateJp: {
    name: 'ExtraUpdate',
    colors: [
      {x: 104, y:  556, r:  36, g: 204, b: 239, match: true, threshold: 80},  // light blue top left
      {x: 104, y: 1194, r:  36, g: 204, b: 239, match: true, threshold: 80},  // light blue bottom left
      {x: 700, y: 1100, r: 238, g: 174, b:   8, match: true, threshold: 80},  // OK button
      {x: 200, y: 1100, r: 238, g: 174, b:   8, match: true, threshold: 80},  // Cancel button
      {x: 644, y:  676, r: 248, g: 248, b: 248, match: true, threshold: 80},  // Left of big white "o" letter
      {x: 694, y:  676, r: 248, g: 248, b: 248, match: true, threshold: 80},  // Right of big white "o" letter
      {x: 668, y:  676, r:  58, g:  93, b: 148, match: true, threshold: 80},  // Middle of big white "o" letter
      {x: 422, y:  998, r:  48, g:  93, b: 148, match: true, threshold: 80},  // Middle of small white "o" letter
      {x: 406, y:  998, r: 248, g: 248, b: 248, match: true, threshold: 80},  // Left of small white "o" letter
      {x: 434, y:  998, r: 248, g: 248, b: 248, match: true, threshold: 80}   // Right of small white "o" letter
    ],
    back: {x: 770, y: 1100},
    next: {x: 770, y: 1100}
  },
  ExtraUpdateEn: {
    name: 'ExtraUpdate',
    colors: [
      {x: 104, y:  556, r:  36, g: 204, b: 239, match: true, threshold: 80},  // light blue top left
      {x: 104, y: 1194, r:  36, g: 204, b: 239, match: true, threshold: 80},  // light blue bottom left
      {x: 700, y: 1100, r: 238, g: 174, b:   8, match: true, threshold: 80},  // OK button
      {x: 200, y: 1100, r: 238, g: 174, b:   8, match: true, threshold: 80},  // Cancel button
      {x: 520, y:  680, r: 248, g: 248, b: 248, match: true, threshold: 80},  // Left of big white "o" letter
      {x: 558, y:  680, r: 248, g: 248, b: 248, match: true, threshold: 80},  // Right of big white "o" letter
      {x: 538, y:  680, r:  55, g:  94, b: 148, match: true, threshold: 80},  // Middle of big white "o" letter
      {x: 674, y: 1002, r:  60, g: 100, b: 150, match: true, threshold: 80},  // Middle of small white "o" letter
      {x: 662, y: 1002, r: 240, g: 240, b: 240, match: true, threshold: 80},  // Left of small white "o" letter
      {x: 686, y: 1002, r: 240, g: 240, b: 240, match: true, threshold: 80}   // Right of small white "o" letter
    ],
    back: {x: 770, y: 1100},
    next: {x: 770, y: 1100}
  },
  RubyResetDifficulty: {
    name: 'RubyResetDifficulty',
    colors: [
      {x: 594, y:  972, r: 247, g:  81, b:  82, match: true, threshold: 80},  // red arrow between numbers
      {x: 610, y: 1166, r: 189, g:   0, b:  41, match: true, threshold: 80},  // ruby next to "10"
      {x: 588, y: 1096, r:  25, g: 174, b: 214, match: true, threshold: 80},  // light blue next to above ruby
      {x: 867, y: 1270, r: 238, g: 174, b:   8, match: true, threshold: 80},  // OK button
      {x: 425, y: 1275, r: 238, g: 174, b:   8, match: true, threshold: 80}   // Cancel button
    ],
    back: {x: 425, y: 1275},
    next: {x: 867, y: 1270}
  }
};

function TaskController() 
{ 
  this.tasks = {},this.isRunning = !1, this.interval = 50 
} 

TaskController.prototype.getFirstPriorityTaskName = function () { 
  var t = null, n = Date.now();
   for (var s in this.tasks) { 
    var i = this.tasks[s]; n - i.lastRunTime < i.interval || (null !== t ? i.priority < t.priority ? t = i : i.interval > t.interval ? t = i : i.lastRunTime < t.lastRunTime && (t = i) : t = i) 
  } 
  return null === t ? "" : t.name 
}, 

TaskController.prototype.loop = function () { 
  for (console.log("loop start"); this.isRunning;) { 
    var t = this.getFirstPriorityTaskName(), n = this.tasks[t];
    void 0 !== n && (n.run(), n.lastRunTime = Date.now(), n.runTimes--, 0 === n.runTimes && delete this.tasks[t]), sleep(this.interval) 
  } 
  this.isRunning = !1, console.log("loop stop") 
}, 

TaskController.prototype.updateRunInterval = function (t) { 
  t < this.interval && t >= 50 && (this.interval = t) 
}, 

TaskController.prototype.newTaskObject = function (t, n, s, i, o) { 
  return { name: t, run: n, interval: s || 1e3, runTimes: i || 0, priority: o, lastRunTime: 0, status: 0 } 
}, 

TaskController.prototype.newTask = function (t, n, s, i, o) { 
  if (void 0 === o && (o = !1), "function" == typeof n) { var e = this.newTaskObject(t, n, s, i, 0);
     o && (e.lastRunTime = Date.now()), this.updateRunInterval(e.interval); 
     var r = "system_newTask_" + t, a = this.newTaskObject(r, function () { this.tasks[t] = e }.bind(this), 0, 1, -20); 
     return this.tasks[r] = a, e 
    } 
    console.log("Error not a function", t, n) 
}, 
    
TaskController.prototype.removeTask = function (t) { 
  var n = "system_removeTask_" + Date.now().toString(), s = this.newTaskObject(n, 
    function () { 
    delete this.tasks[t] 
  }.bind(this), 0, 1, -20); 
  this.tasks[n] = s 
}, 

TaskController.prototype.removeAllTasks = function () { 
  var t = "system_removeAllTask_" + Date.now().toString(), n = this.newTaskObject(t, 
    function () { 
      for (var t in this.tasks) delete this.tasks[t] 
    }.bind(this), 0, 1, -20); this.tasks[t] = n 
}, 

TaskController.prototype.start = function () { 
  this.isRunning || (this.isRunning = !0, this.loop()) 
}, 

TaskController.prototype.stop = function () { 
  this.isRunning && (this.isRunning = !1, console.log("wait loop stop...")) 
};


var ts;
var gTaskController;

// Utils
function isSameColor(c1, c2, diff) {
  if (diff === undefined) {
    diff = 20;
  }
  return Math.abs(c1.r - c2.r) <= diff
      && Math.abs(c1.g - c2.g) <= diff
      && Math.abs(c1.b - c2.b) <= diff;
}

function absColor(c1, c2) {
  return Math.abs(c1.r - c2.r) + Math.abs(c1.g - c2.g) + Math.abs(c1.b - c2.b);
}

function nowTime() {
  var offset = (new Date().getTimezoneOffset()) * 60 * 1000;
  return Date.now() + offset;
}

function debug() {
  if (Config.debugLogs) {
    var argsArray = Array.prototype.slice.call(arguments);
    var newArgs = ['*DEBUG*'].concat(argsArray);
    log.apply(null, newArgs);
  }
}

function log() {

  var args = [];
  if (ts !== undefined && ts.showHeartLog && ts.record && ts.record['hearts_count']) {
    var msg = "";
    msg += "R:"+ts.record['hearts_count'].receivedCount+" ";
    msg += "S:"+ts.record['hearts_count'].sentCount;
    if (gTaskController !== undefined && gTaskController.tasks !== undefined) {
      var sendTask = gTaskController.tasks["sendHearts"];
      if (sendTask !== undefined) {
        if (sendTask.lastRunTime === 0) {
          msg += "/0";
        } else {
          var next = (nowTime() - (sendTask.lastRunTime + sendTask.interval)) / 60000;
          msg += "/" + (+next.toFixed(0));
        }
      }
    }
    args.push("["+msg+"]");
  }
  for (var i = 0; i < arguments.length; i++) {
    if (typeof arguments[i] == 'object') {
      arguments[i] = JSON.stringify(arguments[i], null, 2);
    } else if (typeof arguments[i] == 'function') {
      if (Config.debugLogs)
        arguments[i] = arguments[i]();
      else
        arguments[i] = "";
    }
    args.push(arguments[i]);
  }
  console.log.apply(console, args);
}

// ============================TSUM=============================== //

var Config = {
  recordDir: 'tsum_record',
  tsumWidth: 16,
  tsumBoundW: 13, // tsumWidth / 2 + 2
  tsumBoundH: 13,
  screenResize: 200,
  gameContinueDelay: 400,
  colors: [[255,0,0], [0,255,0], [0,0,255], [0,255,255], [255,0,255]],
  maxChain:3,
  debugLogs: false
};

// Definitions assuming screen resolution of 1080 * 1920
var Button = {
  gameBubblesFrom: {x: 100, y: 632},
  gameBubblesTo: {x: 1000, y: 1532},
  gameQuestionCancel: {x: 400, y: 1352},
  gameQuestionCancel2: {x: 400, y: 1072},
  gameStop: {x: 440, y: 1072},
  gameSkill1: {x: 160, y: 1702},
  gameSkill2: {x: 95, y: 1702},
  gameRand: {x: 985, y: 1652, color: {"a":0,"b":6,"g":180,"r":232}},
  gamePause: {x: 983, y: 322, color: {"a":0,"b":9,"g":188,"r":239}},
  gameContinue: {x: 540, y: 1342, color: {"a":0,"b":13,"g":175,"r":240}},
  outGameItems: [
    {x: 205, y: 889},    // +Score
    {x: 435, y: 893},    // +Coin
    {x: 651, y: 889},    // +Exp
    {x: 871, y: 893},    // +Time
    {x: 201, y: 1167},   // +Bubble
    {x: 424, y: 1170},   // 5>4
    {x: 610, y: 1175}],  // +Combo
  outStart: {x: 500, y: 1592, color: {"a":0,"b":129,"g":111,"r":236}}, // 開始
  outClose: {x: 500, y: 1592, color: {"a":0,"b":7,"g":180,"r":236}}, // 關閉
  outReceive: {x: 910, y: 422},
  outReceiveAll: {x: 800, y: 1422},
  outReceiveOk: {x: 835, y: 1092, color: {"a":0,"b":6,"g":175,"r":236}},
  outReceiveAllHeartsDisabledJP: {x: 679, y: 880, color: {"a":0,"b":214,"g":129,"r":41}},
  outReceiveAllRubiesEnabledJP: {x: 261, y: 705, color: {"a":0,"b":33,"g":178,"r":247}},
  outReceiveAllOkJP: {x: 835, y: 1258, color: {"a":0,"b":6,"g":175,"r":236}},
  outReceiveItemSetOk: {x: 830, y: 1260, color: {"a":0,"b":8,"g":176,"r":238}},
  outReceiveClose: {x: 530, y: 1372},
  outReceiveOneBase: {y: 569},
  outReceiveOne: {x: 840, color: {"a":0,"b":30,"g":181,"r":235}, color2: {"a":0,"b":119,"g":74,"r":40}},
  outReceiveOneRubyBase: {y: 651}, // ruby
  outReceiveOneRuby: {x: 295, color: {r: 224, g: 93, b: 101}}, // ruby
  outReceiveOneAdBase: { y: 672 }, // ad
  outReceiveOneAd: { x: 290, color: { r: 90, g: 57, b: 25 } }, // ad
  outReceiveTimeout: {x: 600, y: 1092, color: {"a":0,"b":11,"g":171,"r":235}},
  outSendHeartTop: {x: 910, y: 502},
  outSendHeart0: {x: 910, y: 698, color: {"a":0,"b":142,"g":60,"r":209}, color2: {"a":0,"b":140,"g":65,"r":3}},
  outSendHeart1: {x: 910, y: 895, color: {"a":0,"b":142,"g":60,"r":209}, color2: {"a":0,"b":140,"g":65,"r":3}},
  outSendHeart2: {x: 910, y: 1102, color: {"a":0,"b":142,"g":60,"r":209}, color2: {"a":0,"b":140,"g":65,"r":3}},
  outSendHeart3: {x: 910, y: 1304, color: {"a":0,"b":142,"g":60,"r":209}, color2: {"a":0,"b":140,"g":65,"r":3}},
  outSendHeartBottom: {x: 910, y: 1500},
  outSendHeartClose: {x: 666, y: 1426, color: {r: 236, g: 178, b: 9}},
  outSendHeartFrom: {x: 910, y: 602},
  outSendHeartTo: {x: 910, y: 1322},
  outSendHeartEnd: {x: 328, y: 1266, color: {"a":0,"b":132,"g":85,"r":47}},
  outSendHeartEnd2: {x: 227, y: 1262, color: {"a":0,"b":123,"g":78,"r":44}},
  outSendHeartEnd3: {x: 316, y: 1224, color: {r: 55, g: 91, b: 139}},
  outFriendScoreFrom: {x: 550, y: 935, color: {"a":0,"b":140,"g":93,"r":55}},
  outFriendScoreTo: {x: 760, y: 935},
  outHomePage: {x: 60, y: 1000},
  outFriendPage: {x: 60, y: 1130},
  skillLuke1: {x: 1000, y: 1372},
  skillLuke2: {x: 830, y: 1402},
  skillLuke3: {x: 670, y: 1447},
  skillLuke4: {x: 960, y: 1232},
  skillCptLy1: {x: 670, y: 1050},
  skillCptLy2: {x: 310, y: 1050},
  skillCptLy3: {x: 540, y: 414},
  outReceiveNameFromBase: {y: 532},
  outReceiveNameFrom: {x: 150},
  outReceiveNameToBase: {y: 670},
  outReceiveNameTo: {x: 660},
  moneyInfoBox: {x: 430, y: 188, w: 230, h: 56},
  outOpenTsumCollectionOrder: {x: 983, y: 890, r: 165, g: 85, b: 49},

  outCloseTsumCollectionOrderOld: {x: 552, y: 1365, r: 247, g: 174, b: 8},
  outTsumCollectionOrderByReleaseDateOld: {name: 'By Release Date', x: 331, y: 774, r: 247, g: 178, b: 8},
  outTsumCollectionOrderFavoritesOld: {name: 'By Favorites', x: 765, y: 769, r: 247, g: 174, b: 8},
  outTsumCollectionOrderBySkillOld: {name: 'By Skill', x: 310, y: 988, r: 247, g: 174, b: 8},
  outTsumCollectionOrderByLevelLockOld: {name: 'By Level Lock', x: 766, y: 984, r: 247, g: 174, b: 8},

  outCloseTsumCollectionOrderNew: {x: 552, y: 1585, r: 247, g: 185, b: 8},
  outTsumCollectionOrderByReleaseDateNew: {name: 'By Release Date', x: 330, y: 673, r: 247, g: 178, b: 8},
  outTsumCollectionOrderFavoritesNew: {name: 'By Favorites', x: 765, y: 668, r: 247, g: 174, b: 8},
  outTsumCollectionOrderBySkillNew: {name: 'By Skill', x: 310, y: 900, r: 247, g: 174, b: 8},
  outTsumCollectionOrderByLevelLockNew: {name: 'By Level Lock', x: 766, y: 894, r: 247, g: 174, b: 8},
  outTsumCollectionOrderByEntryDateNew: {name: 'By Entry Date', x: 310, y: 1125, r: 247, g: 174, b: 8},

  outTsumCollectionDoUnlock: {x: 111, y: 760, r: 173, g: 109, b: 57}
};



// page callbacks (this = actual Tsum instance)
function switchToStartupMode() {
  this.isStartupPhase = true;
}


// predefined log messages
var Logs = {
  start: '[TsumTsum] Start',
  stop: '[TsumTsum] Stop',
  sendMessage: 'Send Message...',
  TaskControllerStop: 'TaskController Stop',
  updateApp: 'Please update Robotmon and restart service',
  UnknownState: 'Unknown state, Exiting',
  totalTsums: 'Total Tsums',
  removeSameTsums: 'Remove same Tsums',
  recognizedTsums: 'Recognized Tsums',
  recognizingTsums: 'Recognizing Tsums',
  recognitionStart: 'Start Tsums recognition',
  recognitionTime: 'Time consumed',
  myTsum: 'myTsum',
  clearBubbles: 'Clear bubbles',
  bubbleGenerated: 'Bubble generated',
  calculationPathStart: 'Start path calculation ',
  calculatedPath: 'Calculated path',
  recalculatingPath: 'Connections 0, Recalculating path',
  useSkill: 'Use skill',
  gameStart: 'Game Start',
  gaming: 'Gaming (Slow version)',
  fastGaming: 'Gaming (Fast version)',
  gameOver: 'Game Over',
  confirmingGameOver: 'Screen not recognized, confirming game over (skill animation?)',
  detectScreen: 'Detecting screen (top and bosttom)',
  calculateScreenSize: 'Calculating screen size',
  offset: 'Offset (X, Y, H, W)',
  startTsumTsumApp: 'Start TsumTsum app',
  currentPage: 'Pg:',
  friendsPage: 'Friends page',
  checkBonusItems: 'Check bonus items',
  receiveAllGifts: 'Receive all gifts',
  receiveGiftsOneByOne: 'Receive gift one by one',
  receiveGiftAgain: 'Receive gift again',
  allGiftsReceived: 'All gifts received',
  receivingGiftsCompleted: 'Receiving gifts completed',
  checkUnreceivedGift: 'Check unreceived gift',
  readRecords: 'Reading records',
  saveRecords: 'Saving records',
  recognizingHeartSender: 'Recognizing heart sender',
  calculatingHeartSender: 'Calculating heart sender',
  receiveHeartFromHeartSender: 'Receive',
  recognitionScore: 'Recognition score',
  saveNewFriend: 'Save new friend',
  saveNewFriendAgain: 'Save new friend again',
  hearts: 'hearts from heart sender today',
  startSendingHearts: 'Start sending hearts',
  checkSendingHearts: 'Check sending hearts',
  sendingHearts: 'Sending',
  sendingZeroScore: 'hearts',
  timeIsUp: 'Time\'s up',
  tsumsPage: 'Tsum collection page',
  startUnlockLevel: 'Check for level locked Tsums',
  endUnlockLevel: 'Finished unlocking Tsum levels'
}

var LogsTW = {
  start: '[TsumTsum] 啟動',
  stop: '[TsumTsum] 停止',
  sendMessage: '送出訊息中...',
  TaskControllerStop: 'TaskController 停止',
  updateApp: '請更新 Robotmon 並重新啟動 Service',
  UnknownState: '未知狀態，離開',
  totalTsums: 'Tsums 總數',
  removeSameTsums: '移除相同 Tsums 後總數',
  recognizedTsums: '成功辨識 Tsums',
  recognizingTsums: '辨識 Tsums 中',
  recognitionStart: '開始辨識 Tsums',
  recognitionTime: '耗時',
  myTsum: '我的Tsum',
  clearBubbles: '清除泡泡',
  bubbleGenerated: '產生泡泡',
  calculationPathStart: '開始計算路徑',
  calculatedPath: '成功計算路徑',
  recalculatingPath: '路徑數量為 0, 重新辨識',
  useSkill: '使用技能',
  gameStart: '遊戲開始',
  gaming: '遊戲中 (慢速版)',
  fastGaming: '遊戲中 (快速版)',
  gameOver: '遊戲結束',
  confirmingGameOver: '畫面未辨識，確認遊戲結束 (技能動畫?)',
  detectScreen: '偵測畫面 (頂部與底部)',
  calculateScreenSize: '計算螢幕大小',
  offset: '位移 (X, Y, H, W)',
  startTsumTsumApp: '啟動 TsumTsum 應用程式',
  currentPage: '目前頁面',
  friendsPage: '朋友頁面',
  checkBonusItems: '檢查道具',
  receiveAllGifts: '接收所有禮物',
  receiveGiftsOneByOne: '一個一個接收禮物',
  receiveGiftAgain: '再嘗試接收禮物一次',
  allGiftsReceived: '已接收所有禮物',
  receivingGiftsCompleted: '完成接收禮物',
  checkUnreceivedGift: '檢查未接收的禮物',
  readRecords: '讀取紀錄',
  saveRecords: '儲存紀錄',
  recognizingHeartSender: '辨識送心者',
  calculatingHeartSender: '計算送心者',
  receiveHeartFromHeartSender: '今天送心者已送出',
  recognitionScore: '辨識分數',
  saveNewFriend: '儲存新朋友',
  saveNewFriendAgain: '重新儲存新朋友',
  hearts: '顆愛心',
  startSendingHearts: '開始送愛心',
  checkSendingHearts: '檢查送愛心',
  sendingHearts: '已送出',
  sendingZeroScore: '顆愛心',
  timeIsUp: '送心時間結束',
  tsumsPage: 'Tsum收集页面',
  startUnlockLevel: '检查等级锁定的Tsum',
  endUnlockLevel: '已完成解锁 Tsum 关卡'
}

// Utils for sending message
var _userPlan = -1;
var _lastSendingTime = 0;

function checkFunction(f) {
  return typeof(f) == 'function'
}
function checkCanSendMessage() {
  _userPlan = -1;
  if (getUserPlan !== undefined && checkFunction(sendNormalMessage)) {
    _userPlan = getUserPlan();
  }
  console.log('User Plan', _userPlan);
}
function canSendMessage() {
  if (_userPlan === -1) {
    return false;
  }
  var during = Date.now() - _lastSendingTime;
  return _userPlan >= 0 && during > 60 * 60 * 1000;
}
function sendMessage(topMsg, msg) {
  if (canSendMessage()) {
    _lastSendingTime = Date.now();
    console.log(sendNormalMessage(topMsg, msg));
  }
}
checkCanSendMessage();

// Utils for Tsum

function usingTimeString(startTime) {
  return Date.now() - startTime;
}


function getDistance(t1, t2) {
  var dx = t1.x - t2.x;
  var dy = t1.y - t2.y;
  return dx * dx + dy * dy;
}

function findNearTsum(tsum, tsums) {
  var minDis = Infinity;
  var minTsum = null;
  var idx = -1;

  if (!tsum || !Array.isArray(tsums) || tsums.length === 0) {
    return { dis: Infinity, tsum: null, idx: -1 };
  }

  for (var i = 0; i < tsums.length; i++) {
    var candidate = tsums[i];

    // Skip self-comparison (by reference or unique identifier/position)
    if (candidate === tsum || (candidate.x === tsum.x && candidate.y === tsum.y)) {
      continue;
    }

    var dis = getDistance(tsum, candidate);
    if (dis < minDis) {
      minDis = dis;
      minTsum = candidate;
      idx = i;
    }
  }

  var finalDistance = minDis === Infinity ? Infinity : Math.sqrt(minDis);
  return { dis: finalDistance, tsum: minTsum, idx: idx };
}



function calculateNearTsumPaths(tsum, ts) {
  // 1. Include the starting tsum in the path
  var path = [tsum]; 
  var tsums = ts.slice(); // copy array

  // 2. Remove the starting tsum from candidate list so it isn't matched again
  var initialIdx = tsums.indexOf(tsum);
  if (initialIdx !== -1) {
    tsums.splice(initialIdx, 1);
  }

  while(true) {
    // Stop if we have reached the maximum path length limit
    if (path.length >= Config.maxChain) {
      break;
    }

    var result = findNearTsum(tsum, tsums);
    var minDis = result.dis;
    var minTsum = result.tsum;
    var minIdx = result.idx;
    if (minIdx === -1 || minDis > Config.tsumWidth * 2.8) {
      break;
    }
    tsum = minTsum;
    tsums.splice(minIdx, 1);
    path.push(tsum);
  }
  return path;
}

function calculatePathCenter(path) {
  var cx = 0;
  var cy = 0;
  for (var i in path) {
    cx += path[i].x;
    cy += path[i].y;
  }
  return {x: Math.floor(cx / path.length), y: Math.floor(cy / path.length)};
}


function calculatePaths(board, logs) {
  var tsumsGrouped = {};
  var tsumList = Array.isArray(board) ? board : Object.keys(board).map(function(k) { return board[k]; });

  // 1. Group pieces by type (tsumIdx)
  for (var i = 0; i < tsumList.length; i++) {
    var tsum = tsumList[i];
    if (!tsum) continue;
    var idx = tsum.tsumIdx;
    (tsumsGrouped[idx] = tsumsGrouped[idx] || []).push(tsum);
  }

  var paths = [];
  var seenPathKeys = {};

  // 2. Search paths for each group
  for (var tsumIdx in tsumsGrouped) {
    if (!Object.prototype.hasOwnProperty.call(tsumsGrouped, tsumIdx)) continue;
    var group = tsumsGrouped[tsumIdx];

    if (group.length < 3) continue;

    for (var j = 0; j < group.length; j++) {
      var item = group[j];
      var path = calculateNearTsumPaths(item, group);

      if (path && path.length > 2) {
        var pathKey = getCanonicalPathKey(path);

        if (!seenPathKeys[pathKey]) {
          seenPathKeys[pathKey] = true;
          paths.push(path);
        }
      }
    }
  }

  // 3. Sort paths descending by length
  paths.sort(function(a, b) {
    return b.length - a.length;
  });


  if (ts.debug) {
    if (typeof debug === 'function' && logs && logs.calculatedPath) {
      debug(logs.calculatedPath, paths.length);
    }

    // Log detailed breakdown of each path
    for (var p = 0; p < paths.length; p++) {
      var currentPath = paths[p];
      var pathDetails = currentPath.map(function(node) {
        // Map coordinates or identifiers depending on the object shape
        if (node && node.x !== undefined && node.y !== undefined) {
          return "(" + node.x + "," + node.y + ")";
        }
        return node.tsumIdx !== undefined ? "idx:" + node.tsumIdx : JSON.stringify(node);
      }).join(" -> ");

      log("Path #" + (p + 1) + " (Length " + currentPath.length + "): " + pathDetails);
    }
  }
  return paths;
}

function getCanonicalPathKey(path) {
  var ids = path.map(function(p) {
    return (p.id !== undefined ? p.id : (p.x + ',' + p.y));
  });
  
  var forwardKey = ids.join('-');
  var reverseKey = ids.slice().reverse().join('-');

  return forwardKey < reverseKey ? forwardKey : reverseKey;
}

function convertTo2DArray(arr, size) {
  var result = [];
  for (var i = 0; i < arr.length; i = i + size) {
    result.push(arr.slice(i, i + size));
  }
  return result;
}

function findGameBubbles(img) {
  var cfg = GameBubbleConfig;
  var tmpImg = clone(img);
  var grayImg = bgrToGray(tmpImg);
  releaseImage(tmpImg);
  smooth(grayImg, 2, 9);
  // houghCircles returns centres, unlike the board points findTsums feeds the
  // pathfinder (those are shifted to a tsum's top-left corner).
  var found = houghCircles(grayImg, 3, 1, cfg.minDist, cfg.param1, cfg.param2,
                           cfg.minRadius, cfg.maxRadius);
  releaseImage(grayImg);
  var out = [];
  for (var k in found) {
    out.push({x: found[k].x, y: found[k].y, r: found[k].r});
  }
  return out;
}

function findTsums(img) {
  //var imgSize = getImageSize(img);
  // Calculate scale factor relative to original base size of 200px
  //var scale = imgSize.width / Config.screenResize;
  var scale =  1 ; // Assuming original base size is 200px
  var hsvImg = clone(img);
  var tmpImg = clone(img);
  var grayImg = bgrToGray(tmpImg);
  releaseImage(tmpImg);
  smooth(grayImg, 2, 9);
  convertColor(hsvImg, 40);

  var dp = 1;                             // Lower dp (1 or 2) gives better resolution accuracy at larger sizes
  var minDist = Math.round(22 * scale);    // Min distance between circle centers
  var param1 = 20;                        // Canny high threshold (remains unchanged)
  var param2 = Math.round(10 * scale);     // Accumulator threshold (scales with circle perimeter size)
  var minRadius = Math.round(8 * scale);  // Scaled minimum circle radius
  var maxRadius = Math.round(14 * scale); // Scaled maximum circle radius

  var points = houghCircles(grayImg,3, dp, minDist, param1, param2, minRadius, maxRadius); 
  releaseImage(grayImg);

  if (ts.debug) {
  var debugImg = clone(img); 
  for (var k in points) {
    var p = points[k];
    drawCircle(debugImg, p.x, p.y, minRadius, 255, 0, 0, 1);
  }
    saveImage(debugImg, ts.storagePath + "/tmp/" + ts.runTimes + "-detectedHoughCircles.jpg");
    releaseImage(debugImg);
  }
  
  smooth(hsvImg, 1, 22);
  var results = [];
  for (var k in points) {
    var p = points[k];
    var hsv1, hsv2, hsv3, hsv4, hsv5;
    hsv5 = hsv4 = hsv3 = hsv2 = hsv1 = getImageColor(hsvImg, p.x, p.y);
    if (p.x - 1 >= 0) { hsv2 = getImageColor(hsvImg, p.x - 1, p.y); }
    if (p.x + 1 < Config.screenResize) { hsv3 = getImageColor(hsvImg, p.x + 1, p.y); }
    if (p.y - 1 >= 0) { hsv4 = getImageColor(hsvImg, p.x, p.y - 1); }
    if (p.y + 1 < Config.screenResize) { hsv5 = getImageColor(hsvImg, p.x, p.y + 1); }
    var avgb = (hsv1.b + hsv2.b + hsv3.b + hsv4.b + hsv5.b) / 5;
    var avgg = (hsv1.g + hsv2.g + hsv3.g + hsv4.g + hsv5.g) / 5;
    var avgr = (hsv1.r + hsv2.r + hsv3.r + hsv4.r + hsv5.r) / 5;
    results.push({x: p.x, y: p.y, z: p.r, b: avgb, g: avgg, r: avgr});
  }

  if (ts.debug) {
    saveImage(hsvImg, ts.storagePath + "/tmp/" + ts.runTimes + "-hsvImg.jpg");
  }

  releaseImage(hsvImg);

  return results;
}

function distance3D(p1, p2) {
  var d = Math.sqrt((p1.b-p2.b)*(p1.b-p2.b) + (p1.g-p2.g)*(p1.g-p2.g) + (p1.r-p2.r)*(p1.r-p2.r));
  if (Math.abs(p1.b - p2.b) < 20) { d -= 10; }
  if (Math.abs(p1.g - p2.g) < 20) { d -= 10; }
  if (p1.r < 120 && p2.r < 120) { d -= 20; }
  return d;
}


function classifyTsums(points) {

  var  threshold = 15;
  if (!Array.isArray(points) || points.length === 0) {
    return [];
  }

  var clusters = [];

  for (var i = 0; i < points.length; i++) {
    var p = points[i];
    var bestCluster = null;
    var minDistance = Infinity;

    // Find the CLOSEST existing cluster within threshold
    for (var j = 0; j < clusters.length; j++) {
      var cluster = clusters[j];
      var d = distance3D(cluster, p);

      if (d < threshold && d < minDistance) {
        minDistance = d;
        bestCluster = cluster;
      }
    }

    if (bestCluster) {
      // Add point to closest cluster & update running average color
      bestCluster.points.push(p);
      var count = bestCluster.points.length;
      bestCluster.sumb += p.b;
      bestCluster.sumg += p.g;
      bestCluster.sumr += p.r;
      bestCluster.b = bestCluster.sumb / count;
      bestCluster.g = bestCluster.sumg / count;
      bestCluster.r = bestCluster.sumr / count;
    } else {
      // Start a new cluster
      clusters.push({
        sumb: p.b,
        sumg: p.g,
        sumr: p.r,
        b: p.b,
        g: p.g,
        r: p.r,
        points: [p]
      });
    }
  }

  return clusters;
}

function detectOffsetYInGame() {
  var img = getScreenshot();
  // var img = openImage('/sdcard/img2.jpg');
  var size = getImageSize(img);
  console.log('deviceW', size.width, 'deviceH', size.height);
  var centerY = Math.floor(size.height / 2);

  // find top black
  var topBlackY = 0;
  for (var y = centerY; y >= 0; y--) {
    var color = getImageColor(img, size.width*0.9, y);
    if (isSameColor({r: 0, g: 0, b: 0}, color, 6)) {
      // black color found
      topBlackY = y;
      break;
    }
  }
  console.log('topBlackY', topBlackY);

  var bottomBlackY = size.height;
  for (y = centerY; y < size.height; y++) {
    color = getImageColor(img, size.width*0.9, y);
    if (isSameColor({r: 0, g: 0, b: 0}, color, 6)) {
      // black color found
      bottomBlackY = y;
      break;
    }
  }
  console.log('bottomBlackY', bottomBlackY);
  console.log('screenHeight', bottomBlackY - topBlackY + 1);
  releaseImage(img);
  return -topBlackY;
}

// Tsum struct

function Tsum(isJP, detect, logs) {
  this.debug = false;
  this.autoLaunch = false;
  this.isRunning = true;
  this.isStartupPhase = true;
  this.runTimes = 0;
  this.myTsum = '';
  this.storagePath = getStoragePath();
  // screen size config
  /** @type {{width: number, height: number}}  */
  var size = getScreenSize();
  this.originScreenWidth = size.width;
  this.originScreenHeight = size.height;
  this.screenHeight = size.height;
  this.screenWidth = size.width;
  this.gameOffsetX = 0;
  this.gameOffsetY = 0;
  this.gameHeight = 0;
  this.gameWidth = 0;
  this.resizeRatio = Math.max(1, this.screenWidth / 360); // normalize page screenshots to 360px width

  this.captureGameRatio = 0;
  // playing game screen size config
  this.playOffsetX = 0;
  this.playOffsetY = 0;
  this.playHeight = 0;
  this.playWidth = 0;
  
  this.playResizeWidth = Config.screenResize;
  this.playResizeHeight = Config.screenResize;


  this.tsumCount = 5;
  this.isJP = isJP;
  this.logs = logs;
  this.scoreItem = false;
  this.coinItem = false;
  this.expItem = false;
  this.timeItem = false;
  this.bubbleItem = false;
  this.comboItem = false;
  this.isPause = false;
  this.receiveOneItem = false;
  this.sentToZero = false;
  this.recordReceive = true;
  this.skillInterval = 3000;
  this.skillLevel = 3;
  this.maxChain = 3;
  this.skillType = '';
  this.skillAutoTap = false;
  this.skillAutoTapInterval = 500;
  this._lastSkillAutoTap = 0;
  this.unlockLevelHoursWait = 0;
  this.sendHearts = false;
  this.keepRuby = false;
  this.showHeartLog = true;
  this.sendHeartMaxDuring = 0;
  // Bubble positions from the last board scan, for popGameBubbles.
  this.gameBubbles = [];
  this.boardClusters = [];
  this.boardClustersSizes = [];
  // record
  this.record = {
    hearts_count: {
      receivedCount: 0,
      sentCount: 0
    }
  };
  this.recordImages = {};
  this.receiveCheckLimit = 5;
  this.clearBubbles = true;
  this.autobuyBoxes = 0;
  // this.noSkillLastFeverSec = 0;
  this.claimAllWithoutCoins = false;
  this.nextMonitorExecution = 0;
  this.lastVisitedPages = {init1: true, init2: true, init3: true};  // trigger initial monitor call on script startup
  this.handleLongSkillAnimations = false;
  // How long the play loop tolerates an unrecognized screen before accepting
  // game over (see confirmGameOver). Must outlast the longest burst-skill
  // animation; a real game over exits earlier via ScorePage detection.
  this.gameOverGraceMs = 20 * 1000;
  this.sendHeartsDownwards = true;
  this.init(detect);
}

Tsum.prototype.init = function(detect) {
  log(this.logs.calculateScreenSize);
  var isFat = false;
  if (this.screenHeight / this.screenWidth < 1.5) {
    isFat = true;
    this.gameHeight = this.screenHeight;
    this.gameWidth = this.screenHeight / 1.5;
    this.gameOffsetY = Math.floor((this.gameWidth * 16 / 9 - this.gameHeight) / 2);
    this.gameOffsetX = Math.floor((this.gameWidth - this.screenWidth) / 2);
  } else {
    this.gameWidth = this.screenWidth;
    this.gameHeight = this.screenWidth / 9 * 16;
    this.gameOffsetX = 0;
    this.gameOffsetY = Math.floor((this.gameHeight - this.screenHeight) / 2);
    console.log('??', this.gameHeight, this.screenHeight, this.gameWidth);
  }

  if (detect && this.screenHeight / this.screenWidth > 16 / 9) {
    log('detect screen size (special screen ratio)');
    this.gameWidth = this.screenWidth;
    this.gameHeight = this.gameWidth * 1.5;
    this.gameOffsetX = 0;
    this.gameOffsetY = detectOffsetYInGame();
  }

  this.captureGameRatio = this.gameWidth / 1080;
  if (isFat) {
    this.playWidth = this.gameWidth;
    this.playOffsetX = Math.max(-this.gameOffsetX, 0);
  } else {
    this.playWidth = this.screenWidth;
    this.playOffsetX = 0;
  }
  // noinspection JSSuspiciousNameCombination
  this.playHeight = this.playWidth; // game has square dimension
  this.playOffsetY = 465 * this.captureGameRatio - this.gameOffsetY;

  this.sleep(200);
  log(this.logs.offset, this.gameOffsetX, this.gameOffsetY, this.screenHeight, this.screenWidth);
  this.sleep(1000);
  execute("mkdir -p " + this.storagePath + '/tmp');
  this.sleep(200);
  execute("mkdir -p " + this.storagePath + '/' + Config.recordDir);
}

Tsum.prototype.sendMoneyInfo = function() {
  if (!canSendMessage()) {
    return;
  }
  var x = Math.floor(Button.moneyInfoBox.x * this.captureGameRatio - this.gameOffsetX);
  var y = Math.floor(Button.moneyInfoBox.y * this.captureGameRatio - this.gameOffsetY);
  var w = Math.floor(Button.moneyInfoBox.w * this.captureGameRatio);
  var h = Math.floor(Button.moneyInfoBox.h * this.captureGameRatio);
  var img = getScreenshotModify(x, y, w, h, Button.moneyInfoBox.w / 2, Button.moneyInfoBox.h / 2, 80);
  var base64 = getBase64FromImage(img);
  releaseImage(img);
  log(this.logs.sendMessage);
  sendMessage("Tsum Tsum", base64);
}

Tsum.prototype.isAppOn = function() {
  if (!this.autoLaunch) {
    return true;
  }
  var result = execute('dumpsys window').split('mCurrentFocus');
  if (result.length < 2) {
    return false;
  }
  result = result[1].split(" ");
  if (result.length < 3) {
    return false;
  }
  result = result[2].split("/");
  if (result.length < 2) {
    return false;
  }
  var packageName = result[0];
  return packageName.indexOf('LGTMTM') !== -1;
};

function getPackageName(isJP) {
    var packageName = 'com.linecorp.LGTMTM';
    if (!isJP) {
        packageName += 'G';
    }
    return packageName;
}

function startTsumTsumApp(isJP) {
  var packageName = getPackageName(isJP);
  execute('BOOTCLASSPATH=/system/framework/core.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/framework2.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/services.jar:/system/framework/apache-xml.jar:/system/framework/webviewchromium.jar' +
      ' am start --activity-single-top -n ' + packageName + '/com.linecorp.LGTMTM.TsumTsum');
}

Tsum.prototype.startApp = function() {
  if (!this.autoLaunch) {
    return;
  }
  log(this.logs.startTsumTsumApp);
  startTsumTsumApp(this.isJP);
  this.sleep(10000);
  log("TsumTsum app starting.");
}

Tsum.prototype.screenshot = function() {
  return getScreenshotModify(
    0,
    0,
    this.originScreenWidth,
    this.originScreenHeight,
    this.originScreenWidth / this.resizeRatio,
    this.originScreenHeight / this.resizeRatio,
    80
  );
}

Tsum.prototype.playScreenshotSquare = function() {
  return getScreenshotModify(
    this.playOffsetX,
    this.playOffsetY,
    this.playWidth,
    this.playHeight,
    this.playResizeWidth,
    this.playResizeHeight,
    100
  );
}

Tsum.prototype.toResizeXY = function(x, y) {
  var rx = Math.floor((x * this.captureGameRatio - this.gameOffsetX) / this.resizeRatio);
  var ry = Math.floor((y * this.captureGameRatio - this.gameOffsetY) / this.resizeRatio);
  return {x: rx, y: ry};
}

Tsum.prototype.toResizeXYs = function(xy) {
  return this.toResizeXY(xy.x, xy.y);
}

Tsum.prototype.getColor = function(img, xy) {
  var rxy = this.toResizeXYs(xy);
  return getImageColor(img, Math.max(rxy.x, 0), Math.max(rxy.y, 0));
}

Tsum.prototype.toRealXY = function(x, y) {
  var rx = Math.floor(x * this.captureGameRatio - this.gameOffsetX);
  var ry = Math.floor(y * this.captureGameRatio - this.gameOffsetY);
  return {x: rx, y: ry};
}

Tsum.prototype.toRealXYs = function(xy) {
  return this.toRealXY(xy.x, xy.y);
}

Tsum.prototype.tap = function(xy, during) {
  if (during === undefined) {
    during = 50;
  }
  var rxy = this.toRealXYs(xy);
  tap(rxy.x, rxy.y, during);
}

Tsum.prototype.tapDown = function(xy, during) {
  if (during === undefined) {
    during = 50;
  }
  var rxy = this.toRealXYs(xy);
  tapDown(rxy.x, rxy.y, during);
}

Tsum.prototype.moveTo = function(xy, during) {
  if (during === undefined) {
    during = 50;
  }
  var rxy = this.toRealXYs(xy);
  moveTo(rxy.x, rxy.y, during);
}

Tsum.prototype.tapUp = function(xy, during) {
  if (during === undefined) {
    during = 50;
  }
  var rxy = this.toRealXYs(xy);
  tapUp(rxy.x, rxy.y, during);
}

Tsum.prototype.linkTsums = function(path) {
  for (var j = 0; j < path.length; j++) {
    var point = path[j];
    var x = Math.floor(this.playOffsetX + (point.x + Config.tsumWidth / 2) * this.playWidth / this.playResizeWidth);
    var y = Math.floor(this.playOffsetY + (point.y + Config.tsumWidth / 2) * this.playHeight / this.playResizeHeight);
    if (j === 0) {
      tapDown(x, y, 10);
    }
    moveTo(x, y, 10);
    if (j === path.length - 1) {
      tapUp(x, y, 10);
    }
  }
}

Tsum.prototype.linkLongTsums = function(path) {
  for (var j = 0; j < path.length; j++) {
    var point = path[j];
    var x = Math.floor(this.playOffsetX + (point.x + Config.tsumWidth / 2) * this.playWidth / this.playResizeWidth);
    var y = Math.floor(this.playOffsetY + (point.y + Config.tsumWidth / 2) * this.playHeight / this.playResizeHeight);
    if (j === 0) {
      tapDown(x, y, 10);
    }
    moveTo(x, y, 25);
    if (j === path.length - 1) {
      tapUp(x, y, 10);
    }
  }
}


// Tap the bubbles the last board scan found. Taps only -- the positions were
// worked out at scan time -- so this stays inside the window where the chain is
// still clearing. A tap that misses costs nothing: it is not a drag, so it
// links nothing and the game ignores it.
Tsum.prototype.popGameBubbles = function() {
  var bubbles = this.gameBubbles;
  if (!bubbles || bubbles.length === 0) { return; }
  var cfg = GameBubbleConfig;
  var count = Math.min(bubbles.length, cfg.maxTaps);
  for (var i = 0; i < count; i++) {
    var b = bubbles[i];
    var x = Math.floor(this.playOffsetX + b.x * this.playWidth / this.playResizeWidth);
    var y = Math.floor(this.playOffsetY + b.y * this.playHeight / this.playResizeHeight);
    tap(x, y, cfg.tapDuring);
  }
  if (this.debug) { console.log('[Bubbles] popped ' + count); }
  // A bubble only pops once; forget them until the next scan finds them again.
  this.gameBubbles = [];
};

Tsum.prototype.link = function(paths, board) {
  var isBubble = false;
  for (var i in paths) {
    var path = paths[i];
    if (path.length >= 12) {
      isBubble = true;
    }
    this.linkTsums(path);
    this.popGameBubbles();

  }
  return isBubble;
}

Tsum.prototype.findPageObject = function(times, timeout) {
  if (times === undefined) {times = 2;}
  if (timeout === undefined) {timeout = 700;}
  var start = Date.now();
  var page = null;
  while(this.isRunning) {
    var currentPage = null;
    for (var t = 0; t < times; t++) {
      var img = this.screenshot();
      for (var key in Page) {
        page = Page[key];
        currentPage = null;
        var pageColors = page.colors || [];
        for (var i = 0; i < pageColors.length; i++) {
          var diff = absColor(pageColors[i], this.getColor(img, pageColors[i]));
          if ((diff < pageColors[i].threshold) === pageColors[i].match) {
            currentPage = page;
          } else {
            currentPage = null;
            break;
          }
        }
        if (currentPage !== null) {
          debug(this.logs.currentPage, currentPage.name + ' (' + key + ')', 'findPageObject');
          break;
        }
      }
      releaseImage(img);
    } // for times
    if (currentPage !== null) {
      // trigger callback if defined
      if (typeof currentPage.onDetect === "function") {
        var callback = currentPage.onDetect;
        log("Applying fn " + callback.name + "...");
        callback.apply(this);
        log("Applied fn " + callback.name + ".");
      }
      return currentPage;
    }
    if (Date.now() - start > timeout) {
      return null;
    }
  }
}

Tsum.prototype.findPage = function(times, timeout) {
  var page = this.findPageObject(times, timeout);
  if (page !== null) {
    var name = page.name;
    switch (name) {
        case "GamePause":
        case "GamePlaying":
        case "StartPage":
        case "TsumsPage":
        case "TsumTsumStorePage":
          this.isStartupPhase = false;
    }
  }
  return page != null ? page.name : 'unknown';
}

Tsum.prototype.matchesPage = function (pageName) {
  var found = false;
  var img = null;
  for (var pageId in Page) {
    var page = Page[pageId];
    if (pageName === page.name) {
      if (img == null) {
        // lazy init only if page exists
        img = this.screenshot();
      }
      var colors = page.colors || [];
      found = false;
      for (var i = 0; i < colors.length; i++) {
        var color = colors[i];
        found = isSameColor(this.getColor(img, color), color, 20);
        if (!found) {
          break;  // try next page
        }
      }
      if (found)
        break;  // exit search
    }
  }
  if (img != null) {
    releaseImage(img);
  }
  debug("*** Found", pageName, "=", found);
  return found;
}

Tsum.prototype.exitUnknownPage = function() {
  keycode('KEYCODE_DPAD_DOWN', 50);
  this.sleep(500);
  keycode('KEYCODE_ENTER', 50);
  this.tap(Button.gameQuestionCancel);
  this.tap(Button.gameQuestionCancel2);
  this.tap(Button.outClose);
  this.tap(Button.gameStop);
  this.sleep(500);
}

Tsum.prototype.goFriendPage = function() {
  while(this.isRunning) {
    if (!this.isAppOn()) {
      this.startApp();
    }
    if (this.isStartupPhase) {
      // sleep longer to safely detect new event windows which might initially take longer to load
      this.sleep(5000);
    }
    var pageObj = this.findPageObject(2, 1000);
    var page = pageObj != null ? pageObj.name : "unknown";
    log(this.logs.currentPage, page, "goFriend");
    if (page === 'FriendPage') {
      // check again with 3 seoconds delay (Event notification/page might fly in)
      this.sleep(3000);
      page = this.findPage(1, 500);
      if (page === 'FriendPage') {
        this.sendMoneyInfo();
        this.isStartupPhase = false;
        return;
      }
    } else if (page === "ClosePage") {
      this.tap(pageObj.back);
      this.tap({x: 310, y: 1588 - 140});
    } else if (page === 'unknown') {
      this.exitUnknownPage();
    } else {
      this.tap(pageObj.back);
    }
    this.sleep(1000);
  }
}

Tsum.prototype.checkGameItem = function() {
  var isItemsOn = [false, false, false, false, false, false, false];
  if (this.scoreItem) {
    isItemsOn[0] = true;
  }
  if (this.coinItem) {
    isItemsOn[1] = true;
  }
  if (this.expItem) {
    isItemsOn[2] = true;
  }
  if (this.timeItem) {
    isItemsOn[3] = true;
  }
  if (this.bubbleItem) {
    isItemsOn[4] = true;
  }
  if (this.tsumCount === 4) {
    isItemsOn[5] = true;
  }
  if (this.comboItem) {
    isItemsOn[6] = true;
  }
  for(var t = 0; t < 3; t++) {
    var img = this.screenshot();
    var isChange = false;
    for (var i = 0; i < Button.outGameItems.length; i++) {
      var c = this.getColor(img, Button.outGameItems[i]);
      if (c.b > 128) { // off
        if (isItemsOn[i]) {
          this.tap(Button.outGameItems[i]);
          isChange = true;
          this.sleep(500);
        }
      } else { // on
        if (!isItemsOn[i]) {
          this.tap(Button.outGameItems[i]);
          isChange = true;
          this.sleep(500);
        }
      }
    }
    releaseImage(img);
    console.log("Bonus items changed = " + isChange);
    if (!isChange) {
      break;
    }
    this.sleep(500);
  }
  debug(this.logs.checkBonusItems, isItemsOn);
}

Tsum.prototype.goGamePlayingPage = function() {
  while(this.isRunning) {
    if (!this.isAppOn()) {
      this.startApp();
    }
    var pageObj = this.findPageObject(2, 2000);
    var page = pageObj != null ? pageObj.name : "unknown";
    log(this.logs.currentPage, page, "play");
    if (page === 'FriendPage') {
      this.tap(pageObj.next);
      this.sleep(3000);
      this.lastVisitedPages.gameFriend = true;
    } else if (page === 'StartPage') {
      this.sleep(500);
      this.checkGameItem();
      this.sendMoneyInfo();
      this.tap(Button.outStart);
      this.sleep(5000); // avoid checking items again!
      this.lastVisitedPages.gameStart = true;
    } else if (page === 'GamePlaying') {
      // check again
      page = this.findPage(1, 500);
      if (page === 'GamePlaying') {
        this.isStartupPhase = false;
        return;
      }
    } else if (page === 'GamePause') {
      this.isStartupPhase = false;
      this.tap(pageObj.next);
      this.sleep(500);
    } else if (page === 'unknown') {
      this.exitUnknownPage();
    } else if (page === "ClosePage") {
      this.tap(Page.ClosePage.back);
      this.tap({x: 310, y: 1588 - 140});
      this.sleep(1000);
    } else {
      this.tap(pageObj.back);
      this.sleep(1000);
    }
  }
}

Tsum.prototype.goTsumsPage = function() {
  if (!this.isAppOn()) {
    this.startApp();
  }
  this.goFriendPage();
  while(this.isRunning) {
    var page = this.findPageObject(2, 2000);
    if (page != null)
      log(this.logs.currentPage, page.name, "goTsumPage");
    if (page === null) {
      this.exitUnknownPage();
    } else if (page.name === 'TsumsPage') {
      // check again
      page = this.findPageObject(1, 500);
      if (page != null && page.name === 'TsumsPage') {
        return;
      }
    } else if (page.hasOwnProperty('tsums')) {
      this.tap(page.tsums);
      this.sleep(3000);
    } else {
      this.tap(page.back);
      this.sleep(1000);
    }
  }
}

Tsum.prototype.goTsumTsumStorePage = function() {
  if (this.isRunning) {
    if (!this.isAppOn()) {
      this.startApp();
    }
    this.goTsumsPage();
    var pageName = "undefined";
    for (var i = 0; i < 3; i++) {
      this.tap(this.findPageObject().store);
      this.sleep(3000);
      var page = this.findPageObject(5, 2000);
      pageName = page != null ? page.name : 'unknown';
      log("Pg: ", pageName);

      if (page !== null && page.name === 'TsumTsumStorePage') {
      log("AutoBuy: TsumTsumStorePage detected");
      return true;
    }

    }
    log('Unexpected page found:', page, 'goTsumTsumStorePage');
    return false;
  }
}

Tsum.prototype.clearAllBubbles = function(startDelay, endDelay, fromY, delayBetweenLines) {
  delayBetweenLines = delayBetweenLines || 0;
  if (typeof startDelay === 'number' && startDelay > 0) {
    this.sleep(startDelay);
  }

  var fy = Button.gameBubblesFrom.y;
  if (typeof fromY == 'number') {
    fy = fromY;
  }

  for (var by = fy; by <= Button.gameBubblesTo.y; by += 140) {
    for (var bx = Button.gameBubblesFrom.x; bx <= Button.gameBubblesTo.x; bx += 140) {
      this.tap({x: bx, y: by}, 10);
    }
    this.sleep(delayBetweenLines);
  }

  if (typeof endDelay === 'number' && endDelay > 0) {
    this.sleep(endDelay);
  }
}

Tsum.prototype.useCinderellaSkill = function() {
  var path, offset, y;
  for (var i = 0; i < 5; i += 1) {
    for (offset = 0; offset <= 200; offset += 200) {
      path = [];
      for (y = 170; y >= 70; y -= 20)
        path.push({x: Math.abs(offset - 10), y: y});

      for (y = 60; y <= 180; y += 20)
        path.push({x: Math.abs(offset - 40), y: y});

      for (y = 180; y >= 60; y -= 20)
        path.push({x: Math.abs(offset - 70), y: y});

      for (y = 60; y <= 180; y += 20)
        path.push({x: Math.abs(offset - 100), y: y});

      debug("Cinderella i =", i, ", offset =", offset);
      this.linkTsums(path);
    }
  }
  this.sleep(3000);
  this.clearAllBubbles(10, 50, (Button.gameBubblesFrom.y + Button.gameBubblesTo.y) / 2, 200);
}

Tsum.prototype.useSkill = function(board) {
  function isSkillActive(that, img, skillButton) {
    // Don't know the reason why these are checked instead the "active skill" colors, but hopefully for a good reason
    var skillNotActiveColors = [
      {"a": 0, "b": 157, "g": 112, "r": 85},
      {"a": 0, "b": 181, "g": 139, "r": 72},
      {"a": 0, "b": 128, "g": 73, "r": 16},
      {"a": 0, "b": 178, "g": 153, "r": 3},
      {"a": 0, "b": 255, "g": 215, "r": 33}
    ];
    var currentButtonColor = that.getColor(img, skillButton);
    var skillActive = true;
    for (var colorIdx in skillNotActiveColors) {
      var color = skillNotActiveColors[colorIdx];
      var matchesSkillNotActiveColor = isSameColor(color, currentButtonColor, 60);
      // console.log(JSON.stringify(skillButton) + " - " + JSON.stringify(color) + " matches actual color " + JSON.stringify(currentButtonColor) + " = " + matchesSkillNotActiveColor);
      skillActive = skillActive && !matchesSkillNotActiveColor;
    }
    return skillActive;
  }

  if (this.skillType === 'no_skill') {
    return false;
  }

  var page = this.findPage(1, 500);
  if (page !== 'GamePlaying' && page !== 'GamePause') {
    return false;
  }

  for (var i = 0; i < 2; i++) {
    var img = this.screenshot();
    var skillActive1 = isSkillActive(this, img, Button.gameSkill1);
    var skillActive2 = this.skillType === 'block_pair_tsum' && isSkillActive(this, img, Button.gameSkill2);
    releaseImage(img);
    if (skillActive1 || skillActive2) {

    } else {
      this.lastVisitedPages.gameSkillInactive = true;
      return false;
    }
  }
  this.lastVisitedPages.gameSkillActive = true;
/*   if (this.noSkillLastFeverSec > 0) {
    var feverAlmostOver = null;
    do {
      if (feverAlmostOver) {
        this.sleep(100);
      }
      feverAlmostOver = (function (tsum) {
        // skip skill activation if fever and fever almost over and enough seconds remaining
        var img = tsum.screenshot();
        var fever1 = isSameColor(tsum.getColor(img, {x: 340, y: 310}), {r: 0, g: 40, b: 49}, 80);
        var feverRingLeft = rgb2hsv(tsum.getColor(img, {x: 332, y: 1666}));
        var feverRingRight = rgb2hsv(tsum.getColor(img, {x: 746, y: 1666}));
        var hueDifference = Math.min(
            Math.abs(feverRingLeft.h - feverRingRight.h),
            360 - Math.abs(feverRingLeft.h - feverRingRight.h));
        var fever2 = hueDifference > 20;
        var feverStartColorHsv = rgb2hsv(tsum.getColor(img, {x: 345, y: 1670}));
        var offsetX = Math.floor((733 - 345) * tsum.noSkillLastFeverSec / 10);
        var feverEndColorHsv = rgb2hsv(tsum.getColor(img, {x: 345 + offsetX, y: 1670}));
        var feverAlmostOver = feverEndColorHsv.v < 90 || Math.abs(feverStartColorHsv.v - feverEndColorHsv.v) > 10;
        var remainingTimeColor = tsum.getColor(img, {x: 155, y: 190});
        var fewSecondsLeftColor = tsum.getColor(img, {x: 144, y: 195});
        var enoughSecondsRemaining = isSameColor(remainingTimeColor, fewSecondsLeftColor, 60);
        releaseImage(img);
        // debug({fever1: fever1, fever2: fever2, almostOver: feverAlmostOver, enoughTime: enoughSecondsRemaining});
        return fever1 && fever2 && feverAlmostOver && enoughSecondsRemaining;
      })(this);
    } while (feverAlmostOver);
  } */
  log(this.logs.useSkill);
  if (this.skillType === 'block_lukej_s') {
    this.tap(Button.skillLuke1, 30);
    this.tap(Button.skillLuke2, 30);
    this.tap(Button.skillLuke3, 30);
    this.tap(Button.skillLuke4, 30);
  } else if (this.skillType === 'block_lightning_mcqueen_plus_s') {
    this.sleep(200);  // let tsums settle
  } else if (this.skillType === 'block_tiara_minnie_plus_s') {
    // Her picks detonate the board, so wait for it to stop moving first.
    // this.tiaraWaitForSettledBoard();
  }
  this.tap(Button.gameSkill1);
  if (skillActive2) {
    this.tap(Button.gameSkill2);
  }
  if (this.skillType === 'block_lukej_s') {
    for (var i = 0; i < 5; i++) {
      this.tapDown({x: 820, y: 1200}, 20);
      this.moveTo({x: 820, y: 1150}, 20);
      if (i === 0) {
        this.sleep(1160);
      }
      this.sleep(350);
      this.moveTo({x: 825, y: 1000}, 20);
      this.sleep(100);
      this.moveTo({x: 835, y: 800}, 20);
      this.sleep(100);
      this.moveTo({x: 845, y: 600}, 20);
      this.sleep(100);
      this.moveTo({x: 850, y: 450}, 20);
      this.tapUp({x: 850, y: 420}, 20);
      this.sleep(20);
    }
    this.sleep(400);
    this.tap(Button.skillLuke1, 30);
    this.tap(Button.skillLuke2, 30);
    this.tap(Button.skillLuke3, 30);
    this.tap(Button.skillLuke4, 30);
    this.sleep(400);
  } else if(this.skillType === 'block_moana_s') {
    this.clearAllBubbles(2500, 50);
  } else if(this.skillType === 'block_cinderella_s') {
    this.sleep(1500);
    this.useCinderellaSkill(board);
  } else if (this.skillType === 'block_rapunzel_plus_s') {
    this.sleep(1000);
    this.useRapunzelPlusSkill();
  } else if (this.skillType === 'block_cpt_ly_s'){
    this.tap(Button.gameRand, 100);
    this.sleep(2100);
    this.tap(Button.skillCptLy1, 10);
    this.sleep(50);
    this.tap(Button.skillCptLy2, 10);
    if (this.skillLevel >= 2) {
      // 3rd tap
      this.sleep(500);
      this.tap(Button.skillCptLy3, 10);
    }
    if (this.skillLevel >= 4) {
      // 4th tap
      this.sleep(500);
      this.tap(Button.skillCptLy3, 10);
    }
    if (this.skillLevel === 6) {
      // 5th tap
      this.sleep(550);
      this.tap(Button.skillCptLy3, 10);
    }

    var bubbleImg = this.playScreenshotSquare();
    this.gameBubbles = findGameBubbles(bubbleImg);
    releaseImage(bubbleImg);
    this.popGameBubbles;
    //this.clearAllBubbles(600, 0, 1000, 300);
  } else if (this.skillType === 'block_coronation_elsa_s'){
    this.useCoronationElsaSkill(board);
    return false;
  } else if (this.skillType === 'block_lightning_mcqueen_plus_s'){
    this.sleep(2000);
    for (i = 1; i <= 20; i+=1) {
      this.sleep(50);
      img = this.playScreenshotSquare();
      color = getImageColor(img, 120, 184);
      if (isSameColor({r: 245, g: 0, b: 0}, color, 10)) {
        // max speed detected
        this.tap({x: 670, y: 1050}, 10);  // tap somewhere into the game
        i = 20;
      }
      releaseImage(img);
    }
    this.sleep(2500);
    // this.clearAllBubbles(600, 0, 1000, 300);
  } else {
    this.tap(Button.gameRand, 100); // randomize tsums if tsum supports it
    this.sleep(this.skillInterval - 100);
    if (this.skillType === 'burst_bubbles') {
      this.clearAllBubbles(0, 0, 1000, 300);
    }
  }
  return true;
}

// Whether firing the fan now would be a waste: the tsums it shuffles are about
// to be cleared by a skill that is ready or nearly so. It also leaves the board
// churning right as the skill activates, which matters for skills that read the
// board on activation (Tiara Minnie+ blows up whatever is under her pick).
// Costs one screenshot, so only call it where a fan tap is actually pending.
Tsum.prototype.fanWouldBeWasted = function() {
  var img = this.screenshot();
  try {
    return this.checkSkillReadiness(img, Button.gameSkill1) !== 'far';
  } finally {
    releaseImage(img);
  }
};

Tsum.prototype.checkSkillReadiness = function(img, skillButton) {
  // Tiered version of isSkillActive's color check. Same reference colors, two
  // thresholds: tight (25) means firmly empty; loose (60) is the original
  // not-active match. Returns 'active', 'almost', or 'far'.
  var skillNotActiveColors = [
    {"a": 0, "b": 157, "g": 112, "r": 85},
    {"a": 0, "b": 181, "g": 139, "r": 72},
    {"a": 0, "b": 128, "g": 73, "r": 16},
    {"a": 0, "b": 178, "g": 153, "r": 3},
    {"a": 0, "b": 255, "g": 215, "r": 33}
  ];
  var c = this.getColor(img, skillButton);
  var matchesTight = false, matchesLoose = false;
  for (var i = 0; i < skillNotActiveColors.length; i++) {
    var nc = skillNotActiveColors[i];
    if (isSameColor(nc, c, 25)) { matchesTight = true; }
    if (isSameColor(nc, c, 60)) { matchesLoose = true; }
  }
  if (!matchesLoose) { return 'active'; }
  if (!matchesTight) { return 'almost'; }
  return 'far';
};

Tsum.prototype.scanBoardQuick = function() {
  // load game tsums
  var startTime = Date.now();
  var srcImg = this.playScreenshotSquare();

  var points = findTsums(srcImg);
  // Read bubble positions off this same capture and remember them, so popping
  // one after a chain is taps only -- no screenshot in the middle of a batch,
  // which would stall the link cadence and the combo timer with it. Bubbles
  // are big and drift slowly, so a position a second old still lands.
  //this.gameBubbles = this.skillType === 'block_tiara_minnie_plus_s'
  //  ? findGameBubbles(srcImg) : [];
  this.gameBubbles = findGameBubbles(srcImg);
  var tcs = classifyTsums(points);
  tcs.sort(function(a, b) { return a.points.length > b.points.length ? -1: 1; });
  var board = [];
  this.boardClusters = [];
  this.boardClusterSizes = [];
  for(var i in tcs) {
    if (i >= this.tsumCount - 1) {
      break;
    }
    var tc = tcs[i];
    this.boardClusters.push({b: tc.b, g: tc.g, r: tc.r});
    this.boardClusterSizes.push(tc.points.length);
    for (var j in tc.points) {
      var p = tc.points[j];
      board.push({tsumIdx: i, x: p.x - (Config.tsumWidth / 2), y: p.y - (Config.tsumWidth / 2)});
    }
  }
  releaseImage(srcImg);
  return board;
}

// GamePlaying is recognized by HUD pixels on the pause/fan buttons, and a
// long burst-skill animation (e.g. Dapper Hat Mickey) covers them for longer
// than the old two-check window (~5s) while the game is still running, so the
// play loop would bail mid-game and stall on the "unknown" screen. Thus, an
// unrecognized screen alone is not proof of game over; require positive
// confirmation instead: a game that really ends always reaches a known
// out-of-game page (the score tally lands on ScorePage). Poll until the HUD
// comes back (still playing), a known page shows up (game over), or the
// grace window runs out (the old behavior, just later).
Tsum.prototype.confirmGameOver = function() {
  log(this.logs.confirmingGameOver);
  var deadline = Date.now() + this.gameOverGraceMs;
  while (this.isRunning) {
    var page = this.findPage(1, 1500);
    if (page === 'GamePlaying' || page === 'GamePause') {
      return false;
    }
    if (page !== 'unknown') {
      return true;
    }
    if (Date.now() > deadline) {
      return true;
    }
    this.sleep(250);
  }
  return true;
}

Tsum.prototype.taskPlayGameQuick = function() {

  this.goGamePlayingPage();
  this.runTimes = 0;

  // for coronation elsa
  this.elsaRoundId = (this.elsaRoundId || 0)+1;

  while(this.isRunning) {
    var board = this.scanBoardQuick();
    if (board == null) {
      break;
    }
    // for coronation elsa
    if (this.skillType === 'block_coronation_elsa_s'){
      this.elsaReadIce(board);
      elsaNoteIceAlikes(this, board);
    }

    var paths = calculatePaths(board, this.logs);
    paths = paths.splice(0, 6);
    this.link(paths, board);

    this.useSkill(board);

    // double check
    var page = this.findPage(1, 2500);
    if (page !== 'GamePlaying' && page !== 'GamePause') {
      if (this.handleLongSkillAnimations) {
        if (this.confirmGameOver()) {
          log(this.logs.gameOver);
          break;
        }
      } else {

        page = this.findPage(1, 2500);
        if (page !== 'GamePlaying' && page !== 'GamePause') {
          log(this.logs.gameOver);
          break;
        }
      }
    }
    this.runTimes++;
  }
}

Tsum.prototype.taskReceiveAllItems = function() {
  if (this.findPage() === 'GamePause')
    return;
  this.requestTsumMonitor();
  log(this.logs.friendsPage);
  this.goFriendPage();
  this.sleep(1000);
  log(this.logs.receiveAllGifts);
  this.tap(Button.outReceive);
  this.sleep(3500);
  this.tap(Button.outReceiveAll);
  this.sleep(2500);
  this.fetchAllMails();
  this.sleep(2000);
  this.tap(Button.outReceiveClose);
  this.sleep(1500);
  this.tap(Button.outClose);
  this.goFriendPage();
  log(this.logs.allGiftsReceived);
}

Tsum.prototype.fetchAllMails = function() {
  var intlOkButton = Button.outReceiveOk;
  var jpOkButton = Button.outReceiveAllOkJP;

  var img = this.screenshot();

  if (this.isOnScreenshot(img, intlOkButton, 35)) {
    this.tap(intlOkButton);
  } else if (this.isOnScreenshot(img, jpOkButton, 35)) {
    // check important previous buttons before pressing OK
    if (this.keepRuby && this.isOnScreenshot(img, Button.outReceiveAllRubiesEnabledJP)) {
      this.tap(Button.outReceiveAllRubiesEnabledJP);
      this.sleep(500);
    }
    if (this.isOnScreenshot(img, Button.outReceiveAllHeartsDisabledJP)) {
      this.tap(Button.outReceiveAllHeartsDisabledJP);
      this.sleep(500);
    }
    this.tap(jpOkButton);
  } else {
    log("ERROR! No OK button found!");
    this.exitUnknownPage();
  }

  releaseImage(img);
}

Tsum.prototype.readRecord = function() {
  log(this.logs.readRecords);
  var recordDir = this.storagePath + '/' + Config.recordDir;
  var recordFile = recordDir + '/record.txt';
  var txt = readFile(recordFile);
  if (txt !== undefined && txt !== "") {
    this.record = JSON.parse(txt);
  }
  for (var filename in this.record) {
    if (filename !== "hearts_count") {
      this.recordImages[filename] = openImage(recordDir + '/' + filename);
    }
  }
}

Tsum.prototype.recognizeSender = function(img) {
  log(this.logs.recognizingHeartSender);
  var recordDir = this.storagePath + '/' + Config.recordDir;
  var from = this.toResizeXYs(Button.outReceiveNameFrom);
  var to = this.toResizeXYs(Button.outReceiveNameTo);
  var nameImg = cropImage(img, Math.floor(from.x), Math.floor(from.y), Math.floor(to.x - from.x), Math.floor(to.y - from.y));
  var score = 0;
  var existFilename = '';
  for(var key in this.recordImages) {
    if (this.recordImages[key] !== 0) {
      score = getIdentityScore(nameImg, this.recordImages[key]);
      if (score >= 0.98) {
        existFilename = key;
        log(this.logs.recognitionScore + " > 0.98", key, score);
        break;
      }
    }
  }
  // console.log("Score: " + score);
  if (existFilename === '') {
    var now = nowTime();
    var dayTime = Math.floor(now / (24 * 60 * 60 * 1000));
    // not found, new friend
    var filename = 'f_' + now + '.png';
    this.record[filename] = {
      receiveCounts: {},
      lastReceiveTime: now
    };
    this.record[filename].receiveCounts[dayTime] = 1;
    this.recordImages[filename] = nameImg;
    var path = recordDir + '/' + filename;
    log(this.logs.saveNewFriend, path);
    saveImage(nameImg, path);
    this.sleep(80);
    var check = execute("ls " + path);
    if (check.indexOf(filename) === -1) {
      log(this.logs.saveNewFriendAgain);
      saveImage(nameImg, path);
    }
  } else {
    releaseImage(nameImg);
  }
  return existFilename;
}

Tsum.prototype.countReceiveHeart = function(existFilename) {
  if (!existFilename) {
    return;
  }
  log(this.logs.calculatingHeartSender);
  var now = nowTime();
  var dayTime = Math.floor(now / (24 * 60 * 60 * 1000));
  // found
  if (this.record[existFilename].receiveCounts[dayTime] === undefined) {
    this.record[existFilename].receiveCounts[dayTime] = 0;
  }
  this.record[existFilename].receiveCounts[dayTime]++;
  this.record[existFilename].lastReceiveTime = now;
  log(this.logs.receiveHeartFromHeartSender, this.record[existFilename].receiveCounts[dayTime], this.logs.hearts);
}

Tsum.prototype.saveRecord = function() {
  log(this.logs.saveRecords);
  var recordFile = this.storagePath + '/' + Config.recordDir + '/record.txt';
  writeFile(recordFile, JSON.stringify(this.record));
}

Tsum.prototype.releaseRecord = function() {
  for(var filename in this.recordImages) {
    releaseImage(this.recordImages[filename]);
  }
  this.record = {};
  this.recordImages = {};
}

Tsum.prototype.clear = function() {
  var recordDir = getStoragePath() + '/' + Config.recordDir;
  execute('rm -r ' + recordDir);
}

Tsum.prototype.skipAd = function () {
  this.tap(Button.outReceiveOne);
  this.sleep(1000);
  // also gets called for skill and premium tickets, so check we really have an ad!!!
  if (this.matchesPage('ReceiveSkillTicket') || this.matchesPage('ReceivePremiumTicket')) {
    // mcs: I improved ad detection here because I don't get ad mails. So I cannot improve detection in list view
    log("Receive ticket");
    this.tap(Button.outReceiveOk);
  } else {
    log("Ignore Ad");
    if (Config.debugLogs) {
      var img = this.screenshot();
      saveImage(img, this.storagePath + "/tmp/" + this.runTimes + "-detectedAd.jpg");
      releaseImage(img);
    }
    this.sleep(4000);
    // delete ad
    this.tap({ x: 462, y: 1095});
    this.sleep(4000);
    this.tap({ x: 172, y: 1220});
    this.sleep(2000);
    this.tap({ x: 556, y: 1417});
  }
}

Tsum.prototype.taskReceiveOneItem = function() {
  if (this.findPage() === 'GamePause')
    return;
  log(this.logs.friendsPage);
  this.goFriendPage();
  this.sleep(1000)
  this.tap(Button.outReceive);
  log(this.logs.receiveGiftsOneByOne);
  this.sleep(1000);

  var receivedCount = 0;
  var receiveCheckLimit = 1;

  var sender = undefined;
  var receiveTime = Date.now();
  var timeoutCounter = 0;
  var maxTimeoutCount = 100;
  var receivedHeartWithoutCoins = 0;
  while (this.isRunning && timeoutCounter < maxTimeoutCount) {
    this.requestTsumMonitor();
    var img = this.screenshot();
    var isItem = isSameColor(Button.outReceiveOne.color, this.getColor(img, Button.outReceiveOne), 35);
    var isRuby = isSameColor(Button.outReceiveOneRuby.color, this.getColor(img, Button.outReceiveOneRuby), 35);
    var isNonItem = isSameColor(Button.outReceiveOne.color2, this.getColor(img, Button.outReceiveOne), 35);
    var isAd = isSameColor(Button.outReceiveOneAd.color, this.getColor(img, Button.outReceiveOneAd), 35);
    var isOk = isSameColor(Button.outReceiveOk.color, this.getColor(img, Button.outReceiveOk), 35);
    var isOk2 = isSameColor(Button.outReceiveItemSetOk.color, this.getColor(img, Button.outReceiveItemSetOk), 35);
    var isTimeout = isSameColor(Button.outReceiveTimeout.color, this.getColor(img, Button.outReceiveTimeout), 35);
    var isHeartWithoutCoins = this.matchesPage('ReceiveHeartWithoutCoins');
    debug({
      isItem: isItem, isRuby: isRuby, isNonItem: isNonItem, isAd: isAd, isOk: isOk,
      isTimeout: isTimeout, timeoutCounter: timeoutCounter
    });
    releaseImage(img);
    if (isItem) {
      if (isAd) {
        debug("handle ad");
        this.skipAd();
        this.sleep(2000);
        this.lastVisitedPages.receiveOneItemIsAd = true;
        continue;
      }
      if (receivedHeartWithoutCoins > 2) {
        if (receivedCount <= 5 + receivedHeartWithoutCoins) {
          this.sleep(2000);
          debug("Should receive all now");
          this.taskReceiveAllItems();
          this.tap(Button.outReceive);
          this.sleep(1500);
        }
        debug("Closing");
        this.tap(Button.outClose);
        receivedHeartWithoutCoins = 0;
        this.tap(Button.outClose);
        this.goFriendPage();
        this.sleep(500);
        receivedCount = 0;
        sender = "";
        timeoutCounter = 0;
        log(this.logs.checkUnreceivedGift);
        this.sleep(500);
        this.tap(Button.outReceive);
        this.sleep(1500);
      } else if (!this.keepRuby || !isRuby) {
        this.lastVisitedPages.receiveOneItemReceiving = true;
        if (this.recordReceive) {
          img = this.screenshot();
          var isItem2 = isSameColor(Button.outReceiveOne.color, this.getColor(img, Button.outReceiveOne), 30);
          if (isItem2) {
            this.tap(Button.outReceiveOne);
            sender = this.recognizeSender(img);
          }
          releaseImage(img);
        } else {
          sender = "";
        }
        this.tap(Button.outReceiveOne);
        this.sleep(200);
        timeoutCounter = 0;
      } else {
        isNonItem = true;
        receiveTime = 0;
      }
    } else if (isTimeout) {
      debug("isTimeout", "taskReceiveOneItem");
      log(this.logs.receiveGiftAgain);
      this.tap(Button.outReceiveOk);
      this.sleep(1000);
      timeoutCounter = 0;
    } else if (isOk || isOk2) {
      if (this.recordReceive && sender !== undefined && sender !== "") {
        this.countReceiveHeart(sender);
        this.saveRecord();
      }
      this.sleep(100);
      if (isOk) {
        debug("isOK", "taskReceiveOneItem")
        this.lastVisitedPages.receiveOneItemIsOK = true;
        this.tap(Button.outReceiveOk);
      } else {
        debug("isOK2", "taskReceiveOneItem")
        this.lastVisitedPages.receiveOneItemIsOK2 = true;
        this.tap(Button.outReceiveItemSetOk);
      }
      if (sender !== undefined) {
        this.record['hearts_count'].receivedCount++;
        receivedCount++;
      }
      sender = undefined;
      timeoutCounter = 0;
      if (this.claimAllWithoutCoins &&  isHeartWithoutCoins)
        receivedHeartWithoutCoins++;
    } else {
      debug("fetched all so far", "taskReceiveOneItem");
      this.tap(Button.outReceiveClose); // usual close button
    }
    this.sleep(200);

    if (!isNonItem) {
      receiveTime = Date.now();
    }

    if (Date.now() - receiveTime > 3000) {
      debug("took more than 3 seconds", "taskReceiveOneItem");
      this.tap(Button.outClose);
      this.goFriendPage();
      this.sleep(500);
      if (receivedCount === 0 || receiveCheckLimit >= this.receiveCheckLimit) {
        log(this.logs.receivingGiftsCompleted);
        break;
      } else {
        receiveCheckLimit++;
        receivedCount = 0;
        sender = "";
        timeoutCounter = 0;
        this.lastVisitedPages.receiveOneItemNextCheckCycle = true;
        log(this.logs.checkUnreceivedGift);
        this.sleep(500);
        this.tap(Button.outReceive);
        this.sleep(1500);
      }
    }
    timeoutCounter++;
    if (timeoutCounter % 10 === 0) {
      log("Timeout counter = " + timeoutCounter + " / 100");
    }
  }
  if (maxTimeoutCount <= timeoutCounter) {
    // we seem to be trapped, try to exit the trap
    log("I'm stuck! Trying exit...");
    this.exitUnknownPage();
    this.sleep(1000);
    if (this.findPage() === 'unknown') {
      // last attempt
      log("Still stuck! Last try...");
      this.exitUnknownPage();
      this.sleep(1000);
    }
  }
}

Tsum.prototype.friendPageGoToSelf = function() {
  debug("'Scrolling' to own player ranking");
  this.tap(Button.outHomePage, 100);
  this.sleep(2000);
  this.tap(Button.outFriendPage, 100);
  debug("'Scrolled' to own player ranking");
  this.sleep(2000);
}

Tsum.prototype.doHeartSending = function(startTime) {
  var retry = 0;
  var times = 0;
  var hfx = Button.outSendHeartFrom.x;
  var hfy = Button.outSendHeartFrom.y - 40; // hearts from y
  var hty = Button.outSendHeartTo.y + 30;   // hearts to y
  var finished;

  function scrollToNextHearts() {
    if (this.sendHeartsDownwards) {
      this.tapDown({x: Button.outSendHeart3.x - 10, y: Button.outSendHeart3.y}, 50);
      this.moveTo({x: Button.outSendHeart3.x - 10, y: Button.outSendHeart3.y}, 50);
      this.moveTo({x: Button.outSendHeart3.x - 10, y: Button.outSendHeart2.y}, 50);
      this.moveTo({x: Button.outSendHeart3.x - 10, y: Button.outSendHeart1.y}, 50);
      this.moveTo({x: Button.outSendHeart3.x - 10, y: Button.outSendHeart0.y}, 50);
      this.moveTo({x: Button.outSendHeart3.x - 10, y: Button.outSendHeartTop.y}, 500);
      this.tapUp({x: Button.outSendHeart3.x - 10, y: Button.outSendHeartTop.y}, 100);
    } else {
      this.tapDown({x: Button.outSendHeart3.x - 10, y: Button.outSendHeart0.y}, 50);
      this.moveTo({x: Button.outSendHeart3.x - 10, y: Button.outSendHeart0.y}, 50);
      this.moveTo({x: Button.outSendHeart3.x - 10, y: Button.outSendHeart1.y}, 50);
      this.moveTo({x: Button.outSendHeart3.x - 10, y: Button.outSendHeart2.y}, 50);
      this.moveTo({x: Button.outSendHeart3.x - 10, y: Button.outSendHeart3.y}, 50);
      this.moveTo({x: Button.outSendHeart3.x - 10, y: Button.outSendHeartBottom.y}, 500);
      this.tapUp({x: Button.outSendHeart3.x - 10, y: Button.outSendHeartBottom.y}, 100);
    }
  }

  while (this.isRunning && typeof finished === 'undefined') {
    this.requestTsumMonitor();
    times++;
    if (times % 15 === 0) {
      debug("Ensuring friends page");
      this.goFriendPage();
      this.lastVisitedPages.friends = true;
      debug("Ensured friends page");
    }
    var heartsPos = [];

    var img = this.screenshot();
    var isOk = isSameColor(Button.outReceiveOk.color, this.getColor(img, Button.outReceiveOk), 40);
    for (var y = hfy; y <= hty; y += 8) {
      var isHs = isSameColor(Button.outSendHeart0.color, this.getColor(img, {x: hfx, y: y}), 40);
      if (isHs) {
        heartsPos.push({x: hfx, y: y, color: Button.outSendHeart0.color, color2: Button.outSendHeart0.color2});
        y += 140;
      }
    }
    debug("Found " + heartsPos.length + " hearts on current page");
    var isZero = true;
    var fx = Button.outFriendScoreFrom.x;
    var tx = Button.outFriendScoreTo.x;
    var sy = heartsPos.length === 0 ? Button.outFriendScoreFrom.y : (heartsPos[0].y + 35);
    for (var px = fx; px <= tx; px += 20) {
      isZero = isSameColor(Button.outFriendScoreFrom.color, this.getColor(img, {x: px, y: sy}), 40);
      if (!isZero) {
        break;
      }
    }
    var isNotEnd = isSameColor(Button.outSendHeartEnd2.color, this.getColor(img, {x: 225, y: 1056}), 40);
    var isEnd1 = isSameColor({r: 162, g: 84, b: 53}, this.getColor(img, {x: 225, y: 1056}), 40);
    var isEnd2 = isSameColor(Button.outSendHeartEnd.color, this.getColor(img, Button.outSendHeartEnd), 40);
    var isEnd3 = isSameColor(Button.outSendHeartEnd3.color, this.getColor(img, {x: 315, y: 1020}), 40);
    var isTop = isSameColor({r: 255, g: 227, b: 115}, this.getColor(img, {x: 200, y: 670}));
    releaseImage(img);

    var isEnd = !isNotEnd && isEnd1 && isEnd2 && isEnd3;
    debug('isNotEnd', isNotEnd, 'isEnd1', isEnd1, 'isEnd2', isEnd2, 'isEnd3', isEnd3, 'isEnd', isEnd, 'retry', retry, 'heartsLength', heartsPos.length, 'isZero', isZero);

    if (isOk && heartsPos.length === 0) {
      this.tap(Button.outReceiveOk);
    }

    if ((heartsPos.length === 0 && (isEnd || isTop)) || (!this.sentToZero && isZero && heartsPos.length !== 0)) {
      log("'isEnd'=" + isEnd + ", 'isZero'=" + isZero + ", 'isTop'=" + isTop);
      if (retry < 3) {
        scrollToNextHearts.call(this);
        retry++;
        log(this.logs.checkSendingHearts, retry);
        this.sleep(1000);
      } else {
        if (this.sendHeartMaxDuring !== 0) {
          this.sleep(1000);
          this.friendPageGoToSelf();
        }
        debug("Ending taskSendHearts");
        this.sendHeartsDownwards = !this.sendHeartsDownwards;
        // we're finished if we reached the top of the ranking and will send downwards again on the next run
        finished = this.sendHeartsDownwards;
      }
    } else {
      var rTimes = 0;
      for (var h in heartsPos) {
        debug("Try sending heart to", h);
        var success = this.sendHeart(heartsPos[h]);
        debug("Tried sending heart to", h, "with success=" + success);
        if (!success) {
          debug("Try again sending heart to", h);
          success = this.sendHeart(heartsPos[h]);
          debug("Tried again sending heart to", h, "with success=" + success);
        }
        if (success) {
          rTimes++;
          this.record['hearts_count'].sentCount++;
          this.lastVisitedPages.sendHeartSuccess = true;
        } else {
          debug("Try return to FriendPage");
          this.goFriendPage();
          this.sleep(1000);
          debug("Tried return to FriendPage");
        }
        if (!this.isRunning) {
          return true;  // don't let the surrounding job retry this immediately, so we pretend to be finished
        }
      }
      if (heartsPos.length !== 0 && rTimes === 0) {
        continue;
      }
      if (this.recordReceive && heartsPos.length !== 0) {
        this.saveRecord();
      }
      this.sleep(250);
      scrollToNextHearts.call(this);

      this.sleep(400);
      if (this.sendHeartMaxDuring !== 0) {
        if (Date.now() - startTime > this.sendHeartMaxDuring) {
          // we exceeded the maximum allowed sending time. leaving unfinished.
          log(this.logs.timeIsUp);
          finished = true;
        }
      }
      if (heartsPos.length === 0 && isEnd2) {
        this.sleep(700); // end bug
      }
    }
  }
  return finished;
}

Tsum.prototype.taskSendHearts = function() {
  debug("Started taskSendHearts");
  if (this.findPage() === 'GamePause')
    return;
  log(this.logs.friendsPage);
  this.goFriendPage();
  log(this.logs.startSendingHearts);
  this.sleep(1000);
  if (this.sendHeartMaxDuring === 0) {
    this.friendPageGoToSelf();
    tap(0, 0, 20); // Avoid overlap between zero score and pointer location
  }

  var startTime = Date.now();
  var finished;
  do {
    finished = this.doHeartSending(startTime);
    debug("Finished doHeartSending with result " + finished);
    this.sleep(2000);
    if (!finished) {
      this.friendPageGoToSelf();
      tap(0, 0, 20); // Avoid overlap between zero score and pointer location
    }
    this.sleep(2000);
  } while (!finished)
  debug("Finished taskSendHearts");
}

Tsum.prototype.taskAutoUnlockLevel = function() {
  if (this.findPage() === 'GamePause')
    return;
  var btn;
  var i;
  var img;
  var formerOrderButton = null;
  var orderButtons;
  var buttonCloseTsumCollectionOrder;
  var buttonOrderByLevelLock;
  log(this.logs.tsumsPage);
  this.goTsumsPage();
  this.lastVisitedPages.autoUnlockLevelTsum = true;
  log(this.logs.startUnlockLevel);

  // Switch order to "By Level Lock" and remember former selection
  this.tap(Button.outOpenTsumCollectionOrder);
  this.sleep(1000);
  img = this.screenshot();
  // detect old or new ordering view
  if (isSameColor(Button.outCloseTsumCollectionOrderNew, this.getColor(img, Button.outCloseTsumCollectionOrderNew))) {
    orderButtons = [
      Button.outTsumCollectionOrderByReleaseDateNew,
      Button.outTsumCollectionOrderByLevelLockNew,
      Button.outTsumCollectionOrderBySkillNew,
      Button.outTsumCollectionOrderFavoritesNew,
      Button.outTsumCollectionOrderByEntryDateNew
    ];
    buttonCloseTsumCollectionOrder = Button.outCloseTsumCollectionOrderNew;
    buttonOrderByLevelLock = Button.outTsumCollectionOrderByLevelLockNew;
  } else {
    orderButtons = [
      Button.outTsumCollectionOrderByReleaseDateOld,
      Button.outTsumCollectionOrderByLevelLockOld,
      Button.outTsumCollectionOrderBySkillOld,
      Button.outTsumCollectionOrderFavoritesOld
    ];
    buttonCloseTsumCollectionOrder = Button.outCloseTsumCollectionOrderOld;
    buttonOrderByLevelLock = Button.outTsumCollectionOrderByLevelLockOld;
  }
  for (i = 0; i < orderButtons.length; i++) {
    btn = orderButtons[i];
    if (isSameColor(btn, this.getColor(img, btn))) {
      formerOrderButton = btn;
      debug("Found active button: " + btn.name);
      break;
    }
  }
  releaseImage(img);

  this.tap(buttonOrderByLevelLock);
  this.sleep();
  this.tap(buttonCloseTsumCollectionOrder);
  this.sleep(1000);

  // Start looking for locks from first entries
  this.tap({x: 1, y: 1892});  // jump to first Tsum entries
  this.sleep(3000);

  // check all
  do {
    this.requestTsumMonitor();
    var allLocked = true;
    var lockIcons = Page.TsumsPage.lockIcons;
    img = this.screenshot();
    for (i = 0; i < lockIcons.length; i++) {
      var lockIcon = lockIcons[i];
      debug("Checking for lock on i=" + i);
      var realColor = this.getColor(img, lockIcon);
      debug("For i=" + i + " I found color " + JSON.stringify(realColor));
      if (isSameColor(lockIcon, realColor)) {
        debug("Unlocking i=" + i);
        this.lastVisitedPages.autoUnlockLevelUnlock = true;
        var tsumButton = {x: lockIcon.x, y: lockIcon.y - 100};
        this.tap(tsumButton);
        this.sleep(1000);
        this.tap(Button.outTsumCollectionDoUnlock);
        this.sleep(1000);
        this.tap({x: 814, y: 1071, r: 247, g: 174, b: 8}); // OK button
        this.sleep(5000);
        this.tap({x: 600, y: 600}); // just tap anywhere to close the confirmation dialog
        this.sleep(1000);
        debug("Unlocked i=" + i);
      } else {
        debug("No lock found for i=" + i);
        allLocked = false;
        break;
      }
    }
    releaseImage(img);

    // scroll to next page if all Tsums were locked
    if (allLocked) {
      debug("Clicking scroll button to move to next page")
      this.tap({x: 1030, y: 1193, r: 212, g: 239, b: 246}); // arrow, scroll right to next page
      this.sleep(3000);
    }

    // Progress until no more locks exist
  } while (this.isRunning && allLocked)



  // Reset order to former selection
  if (formerOrderButton != null && formerOrderButton !== buttonOrderByLevelLock) {
    this.tap(Button.outOpenTsumCollectionOrder);
    this.sleep(1000);
    this.tap(formerOrderButton);
    this.sleep();
    this.tap(buttonCloseTsumCollectionOrder);
    this.sleep(1000);
  }

  log(this.logs.endUnlockLevel);
}

var BoxStore = {
    oneTimeX: 620,
    tenTimeX: 910,
    onlyOneX: 755,

    probeY: 540,
    tapY: 605,

    probeDx: [-70, -25, 25, 70],

    availableColor: {
        r: 255,
        g: 204,
        b: 10
    },

    soldOutColor: {
        r: 56,
        g: 138,
        b: 223
    },

    buttonDiff: 45,
    buttonVotes: 3
};

Tsum.prototype.readBoxButtonAt = function(img, x) {
    var points = [];

    for (var i = 0; i < BoxStore.probeDx.length; i++) {
        points.push({
            x: x + BoxStore.probeDx[i],
            y: BoxStore.probeY
        });
    }

    var read = this.getColors(img, points);

    var available = 0;
    var soldOut = 0;

    for (var i = 0; i < read.length; i++) {
        if (isSameColor(
            BoxStore.availableColor,
            read[i],
            BoxStore.buttonDiff
        )) {
            available++;
        }
        else if (isSameColor(
            BoxStore.soldOutColor,
            read[i],
            BoxStore.buttonDiff
        )) {
            soldOut++;
        }
    }

    if (available >= BoxStore.buttonVotes) {
        return "available";
    }

    if (soldOut >= BoxStore.buttonVotes) {
        return "soldOut";
    }

    return "none";
};

Tsum.prototype.readBoxPurchase = function() {
    var img = this.screenshot();

    var one;
    var ten;
    var single;

    try {
        one = this.readBoxButtonAt(img, BoxStore.oneTimeX);
        ten = this.readBoxButtonAt(img, BoxStore.tenTimeX);
        single = this.readBoxButtonAt(img, BoxStore.onlyOneX);
    }
    finally {
        releaseImage(img);
    }

    var pair = one !== "none" || ten !== "none";

    var offer = {
        oneTime: null,
        tenTime: null,
        soldOut:
            one === "soldOut" ||
            ten === "soldOut" ||
            single === "soldOut"
    };

    // Some boxes have only one centered purchase button
    if (single === "available" && !pair) {
        offer.oneTime = {
            x: BoxStore.onlyOneX,
            y: BoxStore.tapY
        };
    }
    else {
        if (one === "available") {
            offer.oneTime = {
                x: BoxStore.oneTimeX,
                y: BoxStore.tapY
            };
        }

        if (ten === "available") {
            offer.tenTime = {
                x: BoxStore.tenTimeX,
                y: BoxStore.tapY
            };
        }
    }

    log(
    "AutoBuy buttons:",
    "1x =", one,
    "10x =", ten,
    "single =", single
);
    return offer;
};

Tsum.prototype.taskAutoBuyBoxes = function() {
  if (this.findPage() === 'GamePause')
    return;
  log("Starting taskAutoBuyBoxes");
  if (this.autobuyBoxes === 0) {
    log("Nothing to do", "taskAutoBuyBoxes");
    return;
  }
  var storeHasOpened = this.goTsumTsumStorePage();
  var lastPage = this.findPageObject(1, 200);
  if (!storeHasOpened) {
    log("Leaving AutoBuy Boxes.");
    this.autobuyBoxes = 0;
    return;
  }
  this.lastVisitedPages.autoBuyBoxesStore = true;
  log("Start buying ", this.autobuyBoxes, "boxes - taskAutoBuyBoxes");
  var countUnknownPages = 0, countSamePage = 0;
  var waitingForBoxPurchase = false;
  while (this.isRunning && storeHasOpened && this.autobuyBoxes > 0 && countSamePage < 60) {
    this.requestTsumMonitor();
    var page = this.findPageObject(1, 200);
    if (page != null) {
      countUnknownPages = 0;
      this.lastVisitedPages['autoBuyBoxes' + page.name] = true;
      if (page.name === "OutOfMedals") {
        log("Out Of Medals");
        this.autobuyBoxes = 0;
        break;
      }
      
      if (page.name === "TsumTsumStorePage") {

      // We returned to the store after starting a purchase
      if (waitingForBoxPurchase) {
        this.autobuyBoxes--;
        waitingForBoxPurchase = false;

        log("Bought box.", this.autobuyBoxes, "left");
      }

      if (this.autobuyBoxes === 0) {
        log("Buying finished");
        break;
      }

      // Detect the NEW purchase-button layout
      var offer = this.readBoxPurchase();

      // -------------------------------------------------
      // TWO-BUTTON STORE
      // 1x button is on the LEFT
      // -------------------------------------------------
      if (offer.oneTime !== null) {

        log(
            "AutoBuy: 1x purchase button found at",
            offer.oneTime.x,
            offer.oneTime.y
        );

        waitingForBoxPurchase = true;
        this.tap(offer.oneTime);
        this.sleep(1000);

        lastPage = page;
        continue;
      }

      // -------------------------------------------------
      // SOLD OUT
      // -------------------------------------------------
      if (offer.soldOut) {
        log("AutoBuy: box is sold out.");
        this.autobuyBoxes = 0;
        break;
      }

      // -------------------------------------------------
      // BUTTON NOT RECOGNIZED
      // Don't exit immediately — wait and try again
      // -------------------------------------------------
      log("AutoBuy: purchase button not detected. Retrying...");
      this.sleep(500);

      lastPage = page;
      continue;
      }

      this.tap(page.next);
      if (page === lastPage) {
        countSamePage++;
        debug("countSamePage =", countSamePage);
        if (countSamePage % 10 === 0) {
          debug("I'm stuck?!");
          this.exitUnknownPage();
        }
      } else {
        countSamePage = 0;
      }
      if (countSamePage === 30) {
        // we didn't change the page for at least 15 seconds (30 * 0.500) so try escaping from wherever we are
        log("I'm stuck on buying!");
        this.exitUnknownPage();
        countSamePage = 0;
        this.autobuyBoxes = 0;
      } else if (page.name === Page.Received.name
          || page.name === Page.FriendPage.name
          || page.name === Page.TsumsPage.name) {
        log("Collected all Tsums.");
        this.autobuyBoxes = 0;
      } else if (page.name === Page.MailBox.name) {   // matches when "Buy coins for rubies" appears
        // test again, sometimes falsely matched while page transition
        this.sleep(500);
        page = this.findPageObject(1, 200);
        if (page.name === Page.MailBox.name) {
          log("Not enough coins.");
          this.autobuyBoxes = 0;
        }
      }
      lastPage = page;
    } else {
      countUnknownPages++;
      if (countUnknownPages === 20) {
        // sometimes the final confirmation after having bought doesn't get clicked, so let's use this method
        log("Stuck?");
        this.exitUnknownPage();
      } else if (countUnknownPages > 30) {
        // this probably didn't work on 10, but let's try it again as we don't have something better here
        log("Stuck! Exit...");
        this.exitUnknownPage();
        countUnknownPages = 0;
        this.autobuyBoxes = 0;
      }
    }
    this.sleep(500);
  }
  log("Finished taskAutoBuyBoxes");
}

Tsum.prototype.taskRequestTsumMonitor = function() {
  this.requestTsumMonitor(true);
}

Tsum.prototype.requestTsumMonitor = function(force) {
  var url = this.tsumMonitorUrl;
  if (url.length === 0)
    return;
  if (this.nextMonitorExecution <= Date.now() && Object.keys(this.lastVisitedPages).length >= 2) {
    log("TsumMonitor - GET", url);
    var response = httpClient('GET', url, '', {});
    log("TsumMonitor - Response:", response.trim());
    this.nextMonitorExecution = Date.now() + 60 * 1000;
    this.lastVisitedPages = {};
  } else {
    debug("Skipping TsumMonitor call");
  }
}

Tsum.prototype.taskTsumAppRestart = function () {
    log("Preparing restarting TsumApp");
    if (!this.isAppOn()) {
        this.startApp();
    }
    this.goFriendPage();

    log("Restarting TsumApp");
    var packageName = getPackageName(ts.isJP);
    execute("am force-stop " + packageName);

    ts.sleep(10000);
    if (!this.isAppOn()) {
        this.startApp();
    }
    this.goFriendPage();
    log("TsumTsumApp restarted");
}

Tsum.prototype.sendHeart = function(btn) {
  var unknownCount = 0;
  var isGift = false;
  var isSent = false;
  // log("sendHeart");
  while (this.isRunning) {
    var page = this.findPage(1, 300);
    if (page === "FriendPage") {
      // log("sendHeart A", Date.now() / 1000);
      var img = this.screenshot();
      var isSendBtn = isSameColor(btn.color, this.getColor(img, btn), 40);
      var isSentBtn = isSameColor(btn.color2, this.getColor(img, btn), 40);
      releaseImage(img);
      if ((isSendBtn || !isSentBtn) && !isGift && !isSent) {
        debug("sendHeart A-A", Date.now() / 1000);
        this.tap(btn);
      } else {
        debug("sendHeart A-B", Date.now() / 1000);
        unknownCount += 1;
      }
    } else if (page === "GiftHeart") {
      this.lastVisitedPages.sendHeartGiftHeart = true;
      this.tap(Button.outReceiveOk);
      isGift = true;
      debug("sendHeart B", Date.now() / 1000);
    } else if (page === "Received") {
      this.lastVisitedPages.sendHeartReceived = true;
      this.sleep(100);
      this.tap(Button.outSendHeartClose);
      debug("sendHeart C", Date.now() / 1000);
      if (isGift) {
        isSent = true;
        debug("sendHeart C-C", Date.now() / 1000);
        this.sleep(100);
        return true;
      }
    } else if (page === "FriendInfo") {
      this.tap(Page.FriendInfo.back);
    } else if (page === "ClosePage") {
      this.tap(Page.ClosePage.back);
      this.tap({x: 310, y: 1588 - 140});
    } else {
      unknownCount++;
    }
    if (unknownCount >= 15) {
      debug(this.logs.UnknownState);
      return false;
    }
    // this.sleep(150);
  }
}

Tsum.prototype.sleep = function(t) {
  if (typeof t !== 'number') {
    t = 1000;
  }
  var waitTime = t;
  while (this.isRunning && waitTime > 0) {
    if (waitTime <= 500) {
      sleep(waitTime);
      break;
    } else {
      sleep(500);
      waitTime -= 500;
    }
  }
}

Tsum.prototype.sleepUntil = function(t){
  var d = t - Date.now();
  if(d > 0) { this.sleep(d); }
}

Tsum.prototype.isOnScreenshot = function(img, pageObject, colorDiff) {
  return pageObject && pageObject.color && isSameColor(pageObject.color, this.getColor(img, pageObject), colorDiff)
}


function start(settings) {
  ts = new Tsum(settings['jpVersion'], settings['specialScreenRatio'], settings['langTaiwan'] ? LogsTW : Logs);
  ts.settings = settings
  log(ts.logs.start);
  ts.debug = settings['debugGame'];
  if (settings['bonus5to4']) {
    ts.tsumCount = 4;
  }
  ts.autoLaunch = settings['autoLaunchApp'];
  ts.scoreItem = settings['bonusScore'];
  ts.coinItem = settings['bonusCoin'];
  ts.expItem = settings['bonusExp'];
  ts.timeItem = settings['bonusTime'];
  ts.bubbleItem = settings['bonusBubble'];
  ts.comboItem = settings['bonusCombo'];
  ts.isPause = settings['pauseWhenCalc'];
  ts.receiveOneItem = settings['receiveHeartsOneByOne'];
  ts.receiveSecondItem = settings['receiveHeartsSkipFirst'] || false;
  ts.recordReceive = settings['recordSender'];
  ts.sentToZero = settings['sendHeartsToZeroScore'];
  ts.receiveCheckLimit = settings['mailOpenMax'];
  ts.clearBubbles = settings['clearBubbles'];
  ts.handleLongSkillAnimations = settings['handleLongSkillAnimations'] || false;
  ts.skillInterval = settings['skillWaitingTime'] * 1000;
  ts.skillLevel = settings['skillLevel'];
  ts.skillType = settings['skillType'];
  ts.skillAutoTap = !!settings['skillAutoTap'];
  ts.unlockLevelHoursWait = settings["unlockLevelHoursWait"];
  ts.sendHearts = settings['sendHeartsAuto'];
  ts.showHeartLog = true;
  ts.keepRuby = settings['receiveHeartsSkipRuby'];
  ts.sendHeartMaxDuring = settings['sendHeartsMaxRuntime'] * 60 * 1000;
  if (settings['recordSenderEnlarge']) {
    ts.resizeRatio = 1;
  }
  var yOffset = ts.receiveSecondItem ? 202 : 0;
  Button.outReceiveOne.y = Button.outReceiveOneBase.y + yOffset;
  Button.outReceiveOneRuby.y = Button.outReceiveOneRubyBase.y + yOffset;
  Button.outReceiveOneAd.y = Button.outReceiveOneAdBase.y + yOffset;
  Button.outReceiveNameFrom.y = Button.outReceiveNameFromBase.y + yOffset;
  Button.outReceiveNameTo.y = Button.outReceiveNameToBase.y + yOffset;

  if (ts.recordReceive) {
    ts.readRecord();
  }
  if (ts.record['hearts_count'] === undefined) {
    ts.record['hearts_count'] = {
      receivedCount: 0,
      sentCount: 0
    };
  }

  Config.debugLogs = settings['debugLogs'];
  Config.maxChain = settings['maxChain'];
  ts.autobuyBoxes = settings['autobuyBoxes'];
  // ts.noSkillLastFeverSec = settings['noSkillLastFeverSec'];
  ts.claimAllWithoutCoins = settings['claimAllWithoutCoins'];
  ts.tsumMonitorUrl = settings['tsumMonitorUrl'] || "";
  ts.tsumAppRestartFrequency = settings['tsumAppRestartFrequency'];

  if (!checkFunction(TaskController)) {
    console.log("File lose...");
    return;
  }

  gTaskController = new TaskController();

  if (settings['receiveHeartsOneByOne']) {
    gTaskController.newTask('receiveOneItem', ts.taskReceiveOneItem.bind(ts), settings['mailMinWait'] * 60 * 1000, 0);
  }
  if (settings['receiveAllHearts']) {
    gTaskController.newTask('receiveItems', ts.taskReceiveAllItems.bind(ts), settings['receiveAllHeartsMinWait'] * 60 * 1000, 0);
  }
  if (settings['sendHeartsAuto']) {
    gTaskController.newTask('sendHearts', ts.taskSendHearts.bind(ts), settings['sendHeartsMinWait'] * 60 * 1000, 0);
  }
  if (settings['autoLaunchApp'] && settings['tsumAppRestartFrequency'] > 0) {
    gTaskController.newTask('taskTsumAppRestart', ts.taskTsumAppRestart.bind(ts), settings['tsumAppRestartFrequency'] * 60 * 60 * 1000, 0, true);
  }
  if (checkFunction(outRange)) {
    if (settings['autoPlayGame']) {
      if (settings['unlockLevelHoursWait'] > 0) {
        gTaskController.newTask('autoUnlockLevel', ts.taskAutoUnlockLevel.bind(ts), settings['unlockLevelHoursWait'] * 60 * 60 * 1000, 0);
      }
      gTaskController.newTask('taskPlayGameQuick', ts.taskPlayGameQuick.bind(ts), 1000, 0);
    }
  }
  gTaskController.start();
}

function stop() {
  if (ts != null) {
    log(ts.logs.stop);
    sleep(500);
    ts.isRunning = false;
    sleep(2000);
    // loop stop here...
    if (ts.recordReceive) {
      ts.releaseRecord();
    }
  }
  if (gTaskController !== undefined) gTaskController.removeAllTasks();
  if (gTaskController !== undefined) gTaskController.stop();
  ts = undefined;
}

function genRecordTable() {
  console.log("Generate Record...");
  var recordFile = getStoragePath() + "/tsum_record/record.txt";
  var txt = readFile(recordFile);
  var record = {};
  if (txt !== undefined && txt !== "") {
    try {
      record = JSON.parse(txt);
    } catch(e) {
      return "Can not parse record.txt " + JSON.stringify(e);
    }
  } else {
    return "Can not read record.txt";
  }

  // enhance records with total and average hearts per filename
  var dayMapCount = {};
  var renderRecords = [];
  for (var filename in record) {
    (function (filename) {
      if (filename !== "hearts_count") {
        var totalDay = 0;
        var totalCount = 0;
        var recordElement = record[filename];
        for (var dayTime in recordElement.receiveCounts) {
          var dayCount = recordElement.receiveCounts[dayTime];

          if (dayMapCount[+dayTime] === undefined) {
            dayMapCount[+dayTime] = 0;
          }
          dayMapCount[+dayTime] += dayCount;

          totalDay++;
          totalCount += dayCount;
        }
        var avg = 0;
        if (totalDay !== 0) {
          avg = (totalCount / totalDay).toFixed(1);
        }
        recordElement.all = totalCount;
        recordElement.avg = avg;
        recordElement.filename = filename;
        renderRecords.push(recordElement);
      }
    })(filename, dayMapCount, renderRecords);
  }

  // sort records descending by total
  renderRecords.sort(function (a, b) {
    return b.all - a.all;
  });

  // create sorted dayTime array
  var dayTimesSorted = [];
  for (var dayTime in dayMapCount) {
    if (dayMapCount.hasOwnProperty(dayTime)) {
      dayTimesSorted.push(dayTime);
    }
  }
  dayTimesSorted.sort(function (a, b) {
    return a - b;
  });

  // render records
  var html = "<html><body><style>table { border-collapse: collapse; } th, td { border: solid 1px black; text-align: right; padding: 4px 10px 4px 10px; } .records td:nth-child(2n+5), .records th:nth-child(2n+5) { background-color: lightgray; } .all { background-color: darkseagreen; } .avg { background-color: lightsteelblue; border-right-width: 5px; }</style>";
  html += "<table class='records'>";
  html += "<tr><th>UserImage</th><th class='all'>All</th><th class='avg'>Avg</th>";
  for (var j = 0; j < dayTimesSorted.length ; j++) {
    dayTime = dayTimesSorted[j];
    html += '<th>' + getDayTimeString(new Date(dayTime * (24 * 60 * 60 * 1000))) + '</th>';
  }
  html += "</tr>";
  for (var i = 0; i < renderRecords.length; i += 1) {
    var renderRecord = renderRecords[i];
    filename = renderRecord.filename;
    html += "<tr>";
    // user image
    var filePath = getStoragePath()+"/tsum_record/" + filename;
    var tmpImg = openImage(filePath);
    var base64 = getBase64FromImage(tmpImg);
    releaseImage(tmpImg);
    html += "<td><img src='data:image/png;base64," + base64 + "' /></td>";

    var totalDay = 0;
    var totalCount = 0;
    var tmpHtml = "";
    for (j = 0; j < dayTimesSorted.length ; j++) {
      dayTime = dayTimesSorted[j];
      var dayCount = parseInt(renderRecord.receiveCounts[dayTime]) || 0;
      tmpHtml += '<td>' + dayCount + '</td>';

      totalDay++;
      totalCount += dayCount;
    }
    var avg = 0;
    if (totalDay !== 0) {
      avg = (totalCount/totalDay).toFixed(1);
    }
    html += "<td class='all'>" + totalCount + "</td>";
    html += "<td class='avg'>" + avg + "</td>";
    html += tmpHtml;
    html += "</tr>";
  }
  html += "</table>";
  html += "<br /> <br />";
  // day count
  html += "<table>";
  html += "<tr><th>Date</th><th>Hearts</th></tr>";
  for (j = 0; j < dayTimesSorted.length ; j++) {
    dayTime = dayTimesSorted[j];
    var date = new Date(+dayTime * (24 * 60 * 60 * 1000));
    html += "<tr>";
    html += "<td>" + getDayTimeString(date) + "</td>";
    html += "<td>" + dayMapCount[dayTime] + "</td>";
    html += "</tr>";
  }
  html += "</table>";
  html += "</body></html>";
  var recordName = getRecordFilename();
  var oPath = getStoragePath() + "/tsum_record/" + recordName;
  writeFile(oPath, html);
  return "Download: " + getStoragePath()+"/tsum_record to PC" + "<br />Open: " + recordName;
}

function getDayTimeString(d) {
  return (d.getMonth()+1) + '/' + d.getDate();
}

function getRecordFilename() {
  var d = new Date();
  return 'recordTable_' + d.getFullYear() + '-' + (d.getMonth()+1) + '-' + d.getDate() + '_' + d.getHours() + '-' + d.getMinutes() + '-' + d.getSeconds() + '.html';
}

// input: rgb in [0,255], out: h in [0,360) and s,v in [0,100]
function rgb2hsv(rgb) {
  var r = rgb.r / 255;
  var g = rgb.g / 255;
  var b = rgb.b / 255;
  var v = Math.max(r, g, b), c = v - Math.min(r, g, b);
  var h = c && ((v === r) ? (g - b) / c : ((v === g) ? 2 + (b - r) / c : 4 + (r - g) / c));
  return {h: 60 * (h < 0 ? h + 6 : h), s: Math.round(v && c / v * 100), v: Math.round(v * 100)};
}


Tsum.prototype.useRapunzelPlusSkill = function () {
    var path = [];

    function addVertical(x, reverse) {
        if (!reverse) {
            for (var y = 170; y >= 60; y -= 10) {
                path.push({x: x, y: y});
            }
        } else {
            for (var y = 60; y <= 170; y += 10) {
                path.push({x: x, y: y});
            }
        }
    }

    function addHorizontal(y, x1, x2) {
        if (x1 < x2) {
            for (var x = x1; x <= x2; x += 10) {
                path.push({x: x, y: y});
            }
        } else {
            for (var x = x1; x >= x2; x -= 10) {
                path.push({x: x, y: y});
            }
        }
    }

    addVertical(30, false);
    addHorizontal(60, 30, 70);
    addVertical(70, true);
    addHorizontal(170, 70, 110);
    addVertical(110, false);
    addHorizontal(60, 110, 150);
    addVertical(150, true);

    if (this.debug) {
      if (typeof debug === 'function' && this.logs && this.logs.calculatedPath) {
        debug(this.logs.calculatedPath, path.length);
      }

      var pathDetails = path.map(function(node) {
        if (node && node.x !== undefined && node.y !== undefined) {
          return "(" + node.x + "," + node.y + ")";
        }
        return JSON.stringify(node);
      }).join(" -> ");

      log("Rapunzel+ Path (Length " + path.length + "): " + pathDetails);
    }

    this.linkLongTsums(path);
}

// ==================== Coronation Day Elsa ==================== //

var CoronationElsaConfig = {
    // How long the freeze window stays open, by skill level 1-6, in ms, counted
    // from the end of the activation animation (`leadInMs`). 
    durationMs: [5300, 6300, 7300, 8300, 9300, 10300],
    leadInMs: 1800,
    overlapBandPx: 18,
    overlapClearPx: 25,
    salvos: 2,
    salvoChains: 4,
    salvoMaxChain: 5,
    salvoMaxIced: 4,
    salvoMinLeftMs: 1500,
    iceFormMs: 275,
    // The slice of the window kept for the closing break: the last band forming,
    // the read it is aimed off, and the taps. No chain goes out with less than
    // this left.
    burstTailMs: 800,
    // How far a tsum may sit above the lowest tsum of a row and still be in that
    // row, in the 200px play square (a tsum is 25, rows pitch about 22). A chain
    // whose ends are both inside one row has a band that is horizontal to within
    // // this over its span, which is what keeps the band thin and parallel.
    rowTolerance: 14,
    // Longest chain the row search may return. Short and straight is the point:
    // the band reaches both edges whatever the length, and a long chain wanders
    // off its own line and thickens it.
    rowMaxChain: 5,
    // How many rows a chain may be planned over: its ends in the lowest, the
    // tsum's between them anywhere in these. One row alone holds a colour's
    // tsums two apart, which is a hop the game refuses (see the header).
    rowSpan: 3,
    // The longest hop a planned chain may take, in the 200px play square, as
    // tiers tried in order on one capture: the whole board at the first, then
    // at the next only if that found nothing. Adjacent tsums sit 24-26px apart
    // on a settled board and are the surest to register, so a chain of them
    // wins wherever it is. On a board frozen nearly out the free tsums are
    // scattered islands and every chain left needs 35-43px hops -- inside the
    // 47.5px (`linkReach`) every ordinary chain gambles on, and clear of the
    // ~50px single-row hops the game refused.
    maxHops: [34, 44],
    // How close a drag may pass to a frozen tsum or a bubble, same units --
    // about one tsum radius. A linkable hop is `tsumWidth * linkReach` = 47.5px,
    // so two free tsums can sit one hop apart with ice between them.
    dragClearance: 13,
    // What a frozen tsum reads at its own centre (`BoardPoint.local`, HSV).
    // See the note above. The pale box is the doubled cube and the shards.
    ice: {
        hueMin: 88, hueMax: 165, satMin: 25, satMax: 150, valMin: 175,
        paleSatMax: 25, paleValMin: 235, paleHueMin: 90, paleHueMax: 175,
        paleContrastMax: 35,
        // A tsum in a whitelisted cluster is still ice when its centre reads this
        // bright -- or brighter than that colour's own tsums ever read before the
        // first window, plus `sureValMargin`, whichever is higher.
        sureValMin: 235,
        sureValMargin: 5
    },

    iceAlikeMatch: {hue: 12, sat: 15, val: 40, valUp: 5},
    // What it takes for a colour in the box to count as live rather than a
    // transient: a cluster this big, on this many scans of the round before its
    // first window.
    iceAlikeMinTsums: 4,
    iceAlikeMinScans: 5,
    kind: {on: true, ms: 80, grid: 3, step: 2, dropMax: 25, grabMs: 10, moveMs: 10, releaseMs: 10},
    // Taps spent on the pile. One is enough to set it off; the rest insure
    // against a position the read had slightly wrong.
    burstTaps: 3,
    burstTapDuring: 10,
    // Waited out after a look pops bubbles, before the board is re-captured:
    // tsums slide into the space a popped bubble leaves.
    bubbleSettleMs: 200,
    bubblePopRounds: 3,
    bubbleIceGap: 0.6,
    // An ice-free look that reads fewer than this fraction of the tsums the
    // board is known to hold is a board mid-fall, and is waited out
    // (`settleRetryMs`, up to `settleMaxWaits` times) rather than chained.
    settledFraction: 0.75,
    settleRetryMs: 250,
    settleMaxWaits: 5,
    // Waited out after a burst before anything else works the board: the pile
    // going off is a large clear and the refill scales with it.
    postBurstSettleMs: 250,
    postBurstSettlePerTsumMs: 6,
    postBurstSettleMaxMs: 900,
    // Waited out when a look offers no chain at all before looking again.
    rescanIdleMs: 300,
    // The mid-window break: a board with no row left to chain is a pile ready
    // to spend, and the refill can be frozen again in the window left.
    refreezeStarvedLooks: 2,
    refreezeMinIced: 8,
    refreezeMinWindowLeftMs: 600,
    hiddenIceFraction: 0.8,
    hiddenIceFreeMax: 15,
    // A chain the game took that froze fewer new tsums than this is fruitless.
    // Two in a row, like two starved looks, break the pile.
    chainFreezeMin: 2,
    leftoverBurstMin: 8,
    // A chain the game took clears its tsums; one it did not leaves them where
    // they were. After each chain the next look checks: no more ice than
    // before, and at least `chainStaysMin` of its tsums still read as free
    // within `chainStayPx` -- a dead chain, its tsums left out of the planning
    // until the next break.
    chainStayPx: 8,
    chainStaysMin: 2,
    // How often, at most, a starved look checks the round is still on.
    roundCheckMs: 1000,
    dimValueMax: 100,
    dimMinTsums: 10,
    // Room for the ice colour(s) on top of the board's ordinary colours: every
    // shade the ice reads at is an ordinary cluster to scanBoardQuick and takes
    // one of its `this.tsumCount - 1` kept clusters, so useCoronationElsaSkill
    // raises tsumCount by this many for the window's duration.
    extraClusterSlots: 4
};

Tsum.prototype.elsaRoundOver = function() {
  var page = this.findPage(1,300);
  return page !== 'GamePlaying' && page !== 'GamePause';
}


var elsaIceAlikes = [];
var elsaIceAlikeRound = 0;
var elsaWindowRound = 0;

/** The remembered ice-alike `c` is a re-read of, if any. */
function elsaIceAlikeMatch(c) {
    var m = CoronationElsaConfig.iceAlikeMatch;
    for (var i = 0; i < elsaIceAlikes.length; i++) {
        var a = elsaIceAlikes[i];
        if (c.b >= a.lo.b - m.hue && c.b <= a.hi.b + m.hue
          && c.g >= a.lo.g - m.sat && c.g <= a.hi.g + m.sat
          && c.r >= a.lo.r - m.val && c.r <= a.hi.r + m.valUp) {
            return a;
        }
    }
    return null;
}

/** Whether a colour is known to be alive, not ice: see coronationElsa.ts's header. */
function elsaIceAlike(c) {
    var a = elsaIceAlikeMatch(c);
    return a !== null && a.seen >= CoronationElsaConfig.iceAlikeMinScans ? a : null;
}

/** The centre value from which a tsum of this live colour is ice after all. */
function elsaSureVal(a) {
    var box = CoronationElsaConfig.ice;
    return Math.max(box.sureValMin, a.brightest + CoronationElsaConfig.ice.sureValMargin);
}



function elsaNoteIceAlikes(ts, board) {
    if (elsaIceAlikeRound !== ts.elsaRoundId) {
        elsaIceAlikes = [];
        elsaIceAlikeRound = ts.elsaRoundId;
    }
    if (elsaWindowRound === ts.elsaRoundId) { return; }
    var cfg = CoronationElsaConfig;
    var clusters = ts.boardClusters;
    var sizes = ts.boardClusterSizes;
    var icy = [];
    var bright = [];
    for (var c = 0; c < clusters.length; c++) { icy.push(0); bright.push(0); }
    var none = [];
    for (var i=0; i < board.length; i++) {
        var p = board[i];
        var idx = +p.tsumIdx;
        if( idx < icy.length && elsaPointIsIce(p, none)){
          icy[idx]++;
          if (p.local !== undefined && p.local.r > bright[idx]) { bright[idx] = p.local.r; }
        }
    }
    for ( var j=0; j < clusters.length; j++) {
      var cl = clusters[j];
      if (icy[j] < cfg.iceAlikeMinTsums) { continue; }
      var known = elsaIceAlikeMatch(cl);
      if (known !== null) {
            known.seen++;
            if ( bright[j] > known.brightest) { known.brightest = bright[j]; }
            known.lo = {b: Math.min(known.lo.b, cl.b), g: Math.min(known.lo.g, cl.g), r: Math.min(known.lo.r, cl.r)};
            known.hi = {b: Math.max(known.hi.b, cl.b), g: Math.max(known.hi.g, cl.g), r: Math.max(known.hi.r, cl.r)};
            if (known.seen === cfg.iceAlikeMinScans) {
                // debug('[Elsa] ice-alike learned, {
                //     hue: [known.lo.b, known.hi.b], sat: [known.lo.g, known.hi.g], val: [known.lo.r, known.hi.r],
                //     tsums: sizes[j], brightest: known.brightest
                // });
            }
        } else {
            elsaIceAlikes.push({
              lo: {b: cl.b, g: cl.g, r: cl.r}, hi: { b: cl.b, g: cl.g, r: cl.r},
              seen: 1, brightest: bright[j] || 0
            });
        }
    }
}


function elsaPointIsIce(p, alive) {
    var c = p.local;
    if (c === undefined) { return false; }
    var box = CoronationElsaConfig.ice;
    var a = alive[p.tsumIdx] || null;
    if (c.r >= box.valMin && c.b >= box.hueMin && c.b <= box.hueMax
        && c.g >= box.satMin && c.g <= box.satMax) {
        // A live colour, unless the centre is too bright for one (elsaSureVal).
        return a === null || c.r >= elsaSureVal(a);
    }
    if (a !== null) { return false; }
    var contrast = p.contrast === undefined ? 0 : p.contrast;
    return c.r >= box.paleValMin && c.g <= box.paleSatMax && c.b >= box.paleHueMin
        && c.b <= box.paleHueMax
        && contrast < box.paleContrastMax;
}


function elsaIceAlikeClusters(ts) {
    var clusters = ts.boardClusters;
    var alive = [];
    for (var i = 0; i < clusters.length; i++) {
        alive.push(elsaIceAlike(clusters[i]));
    }
    return alive;
}

/**
 * The board split into what reads as ice and what does not. `board` must
 * already have `.local` filled in (via Tsum.prototype.elsaReadIce).
 */
function elsaSplitIce(ts, board) {
    var alive = elsaIceAlikeClusters(ts);
    var free = [];
    var iced = [];
    for (var i = 0; i < board.length; i++) {
        if (elsaPointIsIce(board[i], alive)) { iced.push(board[i]); } else { free.push(board[i]); }
    }
    return {free: free, iced: iced};
}

function elsaPathIsClear(path, obstacles, clearance) {
  for (var i=1; i < path.length; i++) {
    var a = path[i-1], b = path[i];
    var dx = b.x - a.x, dy = b.y - a.y;
    var lenSq = dx * dx + dy * dy;
    for (var j =0;j < obstacles.length; j++) {
      var p = obstacles[j];
      var keep = clearance + (p.pad || 0);
      var t = lenSq > 0 ? ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq : 0;
      t = t < 0 ? 0 : (t > 1 ? 1 : t);
      var ex = a.x+ t * dx - p.x, ey = a.y + t * dy - p.y;
      if (ex * ex + ey * ey <= keep * keep) { return false;}
    }
  }
  return true;
}

/**
 * The free tsums as rows, lowest row first: each row is its lowest member and
 * everything within 'rowTolerance' above it. Board points are top-left
 * corners, so larger y is lower on the screen.
 */
function elsaRows(free) {
    var tol = CoronationElsaConfig.rowTolerance;
    var sorted = free.slice().sort(function(a, b) { return b.y - a.y; });
    var rows = [];
    var taken = [];
    for (var i = 0; i < sorted.length; i++) { taken.push(false); }
    for (var i2 = 0; i2 < sorted.length; i2++) {
        if (taken[i2]) { continue; }
        var row = [sorted[i2]];
        taken[i2] = true;
        for (var j = i2 + 1; j < sorted.length; j++) {
            if (!taken[j] && sorted[i2].y - sorted[j].y <= tol) {
                row.push(sorted[j]);
                taken[j] = true;
            }
        }
        rows.push(row);
    }
    return rows;
}

/** How far a chain's end line leans off horizontal: |dy| per unit of |dx|. */
function elsaSlant(path) {
    var a = path[0], b = path[path.length - 1];
    return Math.abs(b.y - a.y) / Math.max(Math.abs(b.x - a.x), 1);
}

/**
 * Every pair of 'strip' indices within 'sqrt(maxHopsq)' of each other, as an
 * adjacency list indexed the same as 'strip'. Not in this codebase before
 * this port; a plain O(n^2) scan, since a strip is only ~20 tsums.
 */
function buildTsumNeighbors(strip, maxHopsq) {
    var out = [];
    for (var i = 0; i < strip.length; i++) {
        var neigh = [];
        for (var j = 0; j < strip.length; j++) {
            if (j === i) { continue; }
            var dx = strip[j].x - strip[i].x, dy = strip[j].y - strip[i].y;
            if (dx * dx + dy * dy <= maxHopsq) { neigh.push(j); }
        }
        out.push(neigh);
    }
    return out;
}

/**
 * Every same-colour chain of 3 to 'maxLen' tsums in 'strip' whose hops are all
 * 'maxHop' or shorter -- a plain bounded DFS, since a strip is ~20 tsums and
 * the game's own adjacency keeps the branching small.
 */
function elsaStripChains(strip, maxHop, maxLen, from) {
    var out = [];
    var neighbors = buildTsumNeighbors(strip, maxHop * maxHop);
    var inPath = [];
    for (var i = 0; i < strip.length; i++) { inPath.push(false); }
    var path = [];
    var grow = function(at) {
        path.push(at);
        inPath[at] = true;
        if (path.length >= 3) {
            var chain = [];
            for (var k = 0; k < path.length; k++) { chain.push(strip[path[k]]); }
            chain.tsumIdx = strip[at].tsumIdx;
            out.push(chain);
        }
        if (path.length < maxLen) {
            var next = neighbors[at];
            for (var n = 0; n < next.length; n++) {
                var ni = next[n];
                if (!inPath[ni] && strip[ni].tsumIdx === strip[at].tsumIdx) { grow(ni); }
            }
        }
        path.pop();
        inPath[at] = false;
    };
    if (from !== undefined) {
      grow(from);
    } else {
      for (var s = 0; s < strip.length; s++) { grow(s);}
    }
    return out;
}


function elsaFlattest(paths, obstacles, floor) {
  var cfg = CoronationElsaConfig;
  var best = null;
  var bestSlant = Infinity;
  for (var i = 0; i < paths.length; i++) {
    var p = paths[i];
    var a = p[0], b = p[p.length - 1];
    if (floor !== null && a.y < floor && b.y < floor) { continue; }
    if (!elsaPathIsClear(p, obstacles, cfg.dragclearance)) { continue; }
    var slant = elsaSlant(p);
    if (best === null || slant < bestSlant || (slant === bestSlant && p.length < best.length)) {
      best = p;
      bestSlant = slant;
    }
  }
  return best;
}

/**
 * How many of `iced` a chain's end-to-end line passes within `overlapBandPx`
 * of -- a frozen tsum a second band runs through counts double at the break.
 */
function elsaOverlap(path, iced) {
  var a = path[0], b = path[path.length - 1];
  var dx = b.x - a.x, dy = b.y - a.y;
  var len = Math.sqrt(dx * dx + dy * dy);
  if (len === 0) { return 0; }
  var band = CoronationElsaConfig.overlapBandPx;
  var n = 0;
  for (var i = 0; i < iced.length; i++) {
    var d = Math.abs((iced[i].x - a.x) * dy - (iced[i].y - a.y) * dx) / len;
    if (d <= band) { n++; }
  }
  return n;
}
/**
 * The next chain: the flattest chain anchored in the lowest row that has one,
 * planned over that row and the 'rowSpan - 1' above it. Returns the chain, the
 * index of the row it is anchored in and the hop limit that found it, or null
 * when no row can be chained. See coronationElsa.ts's header for the reasoning.
 */
function elsaRowChain(free, obstacles, iced) {
    var cfg = CoronationElsaConfig;
    var rows = elsaRows(free);
    var scored = iced.length > 0;
    for (var t = 0; t < cfg.maxHops.length; t++) {
        var maxHop = cfg.maxHops[t];
        var found = null;
        for (var r = 0; r < rows.length; r++) {
            var strip = [];
            for (var k = 0; k < cfg.rowSpan && r + k < rows.length; k++) {
                strip = strip.concat(rows[r + k]);
            }
            if (strip.length < 3) { continue; }
            var floor = rows[r][0].y - cfg.rowTolerance;
            var paths = elsaStripChains(strip, maxHop, cfg.rowMaxChain);
            var best = null;
            var over = 0;
            if (scored) {
              var most = -1;
              var tied = [];
              for ( var i =0; i< paths.length; i++) {
                if(elsaFlattest([paths[i]],obstacles, floor) === null ) { continue; }
                var n = elsaPathIsClear(paths[i], obstacles, cfg.overlapClearPx)
                ? elsaOverlap(paths[i], iced) : 0;
                if ( n > most) {  most = n ; tied = [paths[i]]; }
                else if ( n === most) { tied.push(paths[i]); }
              }
              best = elsaFlattest(tied, obstacles , floor);
              over = Math.max(0, most);
            } else {
              best = elsaFlattest(paths, obstacles, floor);
            }
            if (best === null || (found !== null && over <= found.overlap)) {continue;}
            var top = rows[r][0].y;
            for (var si = 0 ; si < strip.length; si++) { top = Math.min(top, strip[si].y); }
            found = {path: best, row:r, hop: maxHop, top: top, bottom: rows[r][0].y, overlap: over};
            if (!scored) {break;}
        }
        if (found !== null) {return found;}
    }
    return null;
}

/** How many of 'path's tsums still stand: points with a free tsum within
 *  'chainStayPx' on the look after the drag. */
function elsaChainStays(path, free) {
    var px = CoronationElsaConfig.chainStayPx;
    var stays = 0;
    for (var i = 0; i < path.length; i++) {
        for (var j = 0; j < free.length; j++) {
            var dx = free[j].x - path[i].x, dy = free[j].y - path[i].y;
            if (dx * dx + dy * dy <= px * px) { stays++; break; }
        }
    }
    return stays;
}

/** 'free' without any tsum standing on a dead chain's point. */
function elsaWithoutDead(free, dead) {
    if (dead.length === 0) { return free; }
    var px = CoronationElsaConfig.chainStayPx;
    var out = [];
    for (var i = 0; i < free.length; i++) {
        var on = false;
        for (var j = 0; j < dead.length && !on; j++) {
            var dx = free[i].x - dead[j].x, dy = free[i].y - dead[j].y;
            on = dx * dx + dy * dy <= px * px;
        }
        if (!on) { out.push(free[i]); }
    }
    return out;
}

/** How long to keep the board after a burst of 'pile' tsums. Capped, because
 *  the wait comes out of the window. */
function elsaPostBurstSettleMs(pile) {
    var cfg = CoronationElsaConfig;
    return Math.min(cfg.postBurstSettleMaxMs,
        cfg.postBurstSettleMs + pile * cfg.postBurstSettlePerTsumMs);
}

/**
 * Fill in '.local' (HSV centre colour) and '.contrast' on every point of a
 * scanBoardQuick() board, for elsaPointIsIce to read.
 *
 * A second screenshot rather than reusing scanBoardQuick's own recognition
 * pass, so ice can be read as many times as a window needs without touching
 * that pass's own tuning. Not measured in situ (unlike the rest of this
 * file's numbers): 'smooth''s blur radius and the neighbour-spread 'contrast'
 * proxy are a reasonable-effort stand-in for coronationElsa.ts's 'light blur
 * that keeps the neighbours out' and its black-and-white-face guard -- if ice
 * reads noisy, or bleed from a neighbouring tsum shows up, this is the first
 * place to revisit.
 */
Tsum.prototype.elsaReadIce = function(board) {
    var img = this.playScreenshotSquare();
    var hsvImg = clone(img);
    releaseImage(img);
    convertColor(hsvImg, 40);
    smooth(hsvImg, 1, 5);
    var max = Config.screenResize - 1;
    for (var i = 0; i < board.length; i++) {
        var p = board[i];
        var cx = Math.min(Math.max(Math.round(p.x + Config.tsumWidth / 2), 0), max);
        var cy = Math.min(Math.max(Math.round(p.y + Config.tsumWidth / 2), 0), max);
        var c = getImageColor(hsvImg, cx, cy);
        p.local = {b: c.b, g: c.g, r: c.r};
        var n1 = getImageColor(hsvImg, Math.max(cx - 3, 0), cy);
        var n2 = getImageColor(hsvImg, Math.min(cx + 3, max), cy);
        var n3 = getImageColor(hsvImg, cx, Math.max(cy - 3, 0));
        var n4 = getImageColor(hsvImg, cx, Math.min(cy + 3, max));
        var vmax = Math.max(c.r, n1.r, n2.r, n3.r, n4.r);
        var vmin = Math.min(c.r, n1.r, n2.r, n3.r, n4.r);
        p.contrast = vmax - vmin;
    }
    releaseImage(hsvImg);
};

/** The bubbles not within `bubbleIceGap * tsumWidth` of a frozen tsum --
 * popping one that close can jostle the ice it sits against. */
function elsaPoppable(bubbles, iced) {
    var half = Config.tsumWidth / 2;
    var gap = Config.tsumWidth * CoronationElsaConfig.bubbleIceGap;
    return bubbles.filter(function(b) {
        for (var i = 0; i < iced.length; i++) {
            var dx = iced[i].x + half - b.x, dy = iced[i].y + half - b.y;
            if (dx * dx + dy * dy < gap * gap) { return false; }
        }
        return true;
    });
}

/**
 * Up to `salvoChains` independent, non-overlapping ordinary chains (capped at
 * `salvoMaxChain` tsums each) over the free tsums, clear of `obstacles` --
 * fired back to back near the start of the window, before ice exists to
 * overlap. `Config.maxChain` is swapped out for the duration of the search
 * since calculatePaths() has no per-call chain-length override.
 */
function elsaSalvo(free, obstacles) {
    var cfg = CoronationElsaConfig;
    var savedMaxChain = Config.maxChain;
    Config.maxChain = cfg.salvoMaxChain;
    var paths;
    try {
        paths = calculatePaths(free, null);
    } finally {
        Config.maxChain = savedMaxChain;
    }
    var out = [];
    var used = [];
    for (var i = 0; i < paths.length && out.length < cfg.salvoChains; i++) {
        var p = paths[i];
        if (p.length < 3 || !elsaPathIsClear(p, obstacles, cfg.dragClearance)) { continue; }
        var overlap = false;
        for (var u = 0; u < used.length && !overlap; u++) {
            overlap = p.indexOf(used[u]) >= 0;
        }
        if (overlap) { continue; }
        out.push(p);
        for (var k = 0; k < p.length; k++) { used.push(p[k]); }
    }
    return out.length >= 2 ? out : [];
}

/** The board's average cluster brightness, weighted by cluster size, or null
 * if fewer than `dimMinTsums` tsums were read -- a screen dimmed for a
 * transition/tally reads far darker than any lit board ever does. */
function elsaBoardValue(ts) {
    var c = ts.boardClusters, n = ts.boardClusterSizes;
    var sum = 0, count = 0;
    for (var i = 0; i < c.length && i < n.length; i++) {
        sum += c[i].r * n[i];
        count += n[i];
    }
    return count >= CoronationElsaConfig.dimMinTsums ? sum / count : null;
}

/** A board point's real screen coordinates (its centre), for raw.tap()/
 * tapDown()/moveTo()/tapUp() calls -- see elsaKindChain. */
function elsaToScreen(ts, p) {
    return {
        x: Math.floor(ts.playOffsetX + (p.x + Config.tsumWidth / 2) * ts.playWidth / ts.playResizeWidth),
        y: Math.floor(ts.playoffsetY + (p.y + Config.tsumWidth / 2) * ts.playHeight / ts.playResizeHeight)
    };
}

// Colours a dead (never-actually-frozen) chain was drawn on, in HSV, per
// round (`elsaMixedRound`, against `ts.elsaRoundId`) -- a suspect list of
// colours the ordinary row-chain read may be confusing with ice, each either
// still open (worth the "kind" press-and-verify treatment) or `confirmed`
// (verified mixed already, no need to press again).
var elsaMixed = [];
var elsaMixedRound = 0;

/** The remembered suspect colour `c` is a re-read of, if any. */
function elsaMixedMatch(ts, c) {
    if (c === undefined) { return null; }
    if (elsaMixedRound !== ts.elsaRoundId) {
        elsaMixed = [];
        elsaMixedRound = ts.elsaRoundId;
    }
    var m = CoronationElsaConfig.iceAlikeMatch;
    for (var i = 0; i < elsaMixed.length; i++) {
        var a = elsaMixed[i];
        if (Math.abs(a.b - c.b) <= m.hue && Math.abs(a.g - c.g) <= m.sat && Math.abs(a.r - c.r) <= m.val) {
            return a;
        }
    }
    return null;
}

/** Whether a colour is a known suspect: the "kind" pass should verify it. */
function elsaIsMixed(ts, c) {
    return elsaMixedMatch(ts, c) !== null;
}

/** Flag a colour a dead chain was just drawn on as a new suspect. */
function elsaNoteMixed(ts, c) {
    if (c === undefined || elsaIsMixed(ts, c)) { return; }
    elsaMixed.push({b: c.b, g: c.g, r: c.r, confirmed: false});
}

/** Settle a suspect colour's verdict: `darkened` (more pool members dropped
 * than kept on the floor-brightness check) confirms it as truly mixed;
 * otherwise it is exonerated and dropped from the suspect list. */
function elsaKindVerdict(ts, c, darkened) {
    var a = elsaMixedMatch(ts, c);
    if (a === null || a.confirmed) { return; }
    if (darkened) {
        a.confirmed = true;
    } else {
        elsaMixed.splice(elsaMixed.indexOf(a), 1);
    }
}

/** The lower median of `values`. */
function skillMedian(values) {
    var sorted = values.slice().sort(function(a, b) { return a - b; });
    return sorted[(sorted.length - 1) >> 1];
}

/** The floor darkness (lowest of r/g/b) under a `grid` x `grid` ring of points
 * `step` px apart around each of `board`'s centres, as its median -- one
 * entry per `board` point. Used by elsaKindChain to tell, before and after
 * holding a tsum down, which same-colour neighbours are still really there.
 *
 * gap-index.js batches this via `getImageColors`; there is no such batch API
 * here, so this loops plain getImageColor() calls instead -- a `board` here
 * is only ~20 points, so this is cheap.
 */
function skillFloorRead(ts, board, grid, step) {
    var half = Config.tsumWidth / 2;
    var max = Config.screenResize - 1;
    var img = ts.playScreenshotSquare();
    var out = [];
    try {
        for (var c = 0; c < board.length; c++) {
            var floors = [];
            for (var i = -grid; i <= grid; i++) {
                for (var j = -grid; j <= grid; j++) {
                    var x = Math.min(Math.max(Math.round(board[c].x + half + i * step), 0), max);
                    var y = Math.min(Math.max(Math.round(board[c].y + half + j * step), 0), max);
                    var col = getImageColor(img, x, y);
                    floors.push(Math.min(col.r, col.g, col.b));
                }
            }
            out.push(skillMedian(floors));
        }
    } finally {
        releaseImage(img);
    }
    return out;
}

/** The mixed-colour verification pass: press `head` down, hold, and read which
 * of `pool` (same tsumIdx, same-row-ish) are still really there by how much
 * their floor brightness changed under the press -- then drag through exactly
 * those (`head` plus everything kept), or just release if none qualify.
 * Returns {path, pool, kept, drops, ms}; `path` is null when nothing to drag. */
function elsaKindChain(ts, head, pool, obstacles) {
    var cfg = CoronationElsaConfig;
    var kc = cfg.kind;
    var from = Date.now();
    var out = {path: null, pool: pool.length, kept: 0, drops: [], ms: 0};
    if (!ts.isRunning) { return out; }
    var base = skillFloorRead(ts, pool, kc.grid, kc.step);
    var at = elsaToScreen(ts, head);
    var finger = at;
    var down = true;
    tapDown(at.x, at.y, kc.grabMs);
    try {
        moveTo(at.x, at.y, kc.moveMs);
        ts.sleep(Math.max(0, kc.ms - kc.grabMs - kc.moveMs));
        var now = skillFloorRead(ts, pool, kc.grid, kc.step);
        var members = [head];
        for (var k = 0; k < pool.length; k++) {
            if (pool[k] === head) { continue; }
            var drop = base[k] - now[k];
            out.drops.push(drop);
            if (drop < kc.dropMax) { members.push(pool[k]); out.kept++; }
        }
        var path = null;
        for (var t = 0; t < cfg.maxHops.length && path === null; t++) {
            path = elsaFlattest(elsaStripChains(members, cfg.maxHops[t], cfg.rowMaxChain, 0), obstacles, null);
        }
        if (path !== null) {
            for (var j = 1; j < path.length; j++) {
                var finger = elsaToScreen(ts, path[j]);
                moveTo(finger.x, finger.y, kc.moveMs);
            }
            out.path = path;
        }
        down = false;
        tapUp(finger.x, finger.y, kc.releaseMs);
    } catch (e) {
        if (down) { tapUp(finger.x, finger.y, kc.releaseMs); }
        throw e;
    }
    out.ms = Date.now() - from;
    return out;
}

/** Set off the pile, and say how many tsums it was aimed at. See
 * coronationElsa.ts's header for the tap ordering reasoning. */
Tsum.prototype.elsaBurstFrozen = function(frozen) {
    if (!this.isRunning) { return 0; }
    var cfg = CoronationElsaConfig;
    var pile = frozen.slice().sort(function(a, b) { return a.y - b.y; });
    var taps = Math.min(cfg.burstTaps, pile.length);
    var step = taps > 0 ? Math.max(1, Math.floor(pile.length / taps)) : 1;
    for (var i = 0; i < taps; i++) {
        var p = pile[i * step];
        var xy = elsaToScreen(this, p);
        tap(xy.x, xy.y, cfg.burstTapDuring);
    }
    this.popGameBubbles();
    // debug(`[Elsa] burst`, {aimedAt: taps, read: frozen.length});
    return taps;
};

/** One settled look at the board: capture (scanBoardQuick + elsaReadIce), split
 * into free and ice, and hand back what a drag must keep away. See
 * coronationElsa.ts's header for the settle/bubble retry reasoning. */
Tsum.prototype.elsaLook = function(closesAt, expected) {
    var cfg = CoronationElsaConfig;
    var expect = expected || 0;
    var free = [];
    var iced = [];
    var waits = 0;
    var pops = 0;
    var popped = 0;
    for (;; ) {
        var board = this.scanBoardQuick();
        this.elsaReadIce(board);
        var split = elsaSplitIce(this, board);
        free = split.free;
        iced = split.iced;
        if (iced.length === 0 && waits < cfg.settleMaxWaits
            && free.length < cfg.settledFraction * expect
            && Date.now() + cfg.settlerRetryMs < closesAt) {
            waits++;
            this.sleep(cfg.settlerRetryMs);
            continue;
        }
        var poppable = elsaPoppable(this.gameBubbles, iced);
        if (poppable.length > 0 && pops < cfg.bubblePopRounds
            && Date.now() + cfg.bubbleSettleMs < closesAt) {
            pops++;
            popped += poppable.length;
            this.gameBubbles = poppable;
            this.popGameBubbles();
            this.sleep(cfg.bubbleSettleMs);
            continue;
        }
        break;
    }
    var obstacles = iced.slice();
    for (var i = 0; i < this.gameBubbles.length; i++) {
        var b = this.gameBubbles[i];
        obstacles.push({
            x: b.x - Config.tsumWidth / 2,
            y: b.y - Config.tsumWidth / 2,
            pad: Math.max(0, b.r - Config.tsumWidth / 2)
        });
    }
    return {free: free, iced: iced, obstacles: obstacles, waits: waits, pops: pops, popped: popped};
};

/**
 * Play the freeze window as the sweep coronationElsa.ts's header describes:
 * chain after chain on the lowest free row, one look per chain, until the
 * window is nearly out; then one break and the bomb it leaves popped.
 *
 * Once ice exists, a row's chain is picked for how many already-frozen tsums
 * its line overlaps rather than only how flat it is (elsaRowChain); a colour
 * flagged suspect from an earlier dead chain is verified by feel before being
 * dragged (elsaKindChain/"kind"); a couple of independent salvo chains fire
 * early, before ice exists to overlap (elsaSalvo); a look that reads far
 * fewer tsums than expected while little is free is treated as ice hidden
 * from the scan, the same as a starved look; and two looks running low on
 * average brightness end the window early as a round-over screen taking the
 * board's place (elsaBoardValue).
 *
 * "board" is the board taskPlayGameQuick scanned before activating, used only
 * to seed the settle gate's expected tsum count.
 */
Tsum.prototype.useCoronationElsaSkill = function(board) {
    var cfg = CoronationElsaConfig;
    var t0 = Date.now();
    var level = Math.min(Math.max(this.skillLevel, 1), cfg.durationMs.length);
    var windowMs = cfg.durationMs[level - 1];
    var openAt = t0 + cfg.leadInMs;
    var closesAt = openAt + windowMs;
    var chainBy = closesAt - cfg.burstTailMs;
    this.sleepUntil(openAt);

    // Ice exists in this round from here on, so ice-alike learning stops.
    elsaWindowRound = this.elsaRoundId;

    // Room for the ice colour(s) on top of the board's ordinary colours, for the
    // rest of this window -- see scanBoardQuick's own `this.tsumCount - 1` cap.
    var savedTsumCount = this.tsumCount;
    this.tsumCount = savedTsumCount + (cfg.extraClusterSlots || 4);

    var expected = board ? board.length : 0;
    var looks = 0, chains = 0, starved = 0, starvedRun = 0, bursts = 0, aimedTaps = 0;
    var iced = [];
    var drawn = null;
    var drawnKind = 0;
    var dead = [];
    var deadChains = 0;
    var fruitlessChains = 0;
    var kindChains = 0;
    var kindLifts = 0;
    var bubblesPopped = 0;
    var salvos = 0;
    var salvoChains = 0;
    var salvoDone = cfg.salvos <= 0;
    var roundOver = false;
    var roundCheckedAt = 0;
    var dimRun = 0;
    try {
        while (this.isRunning && Date.now() < chainBy) {
            var look = this.elsaLook(chainBy, expected);
            looks++;
            bubblesPopped += look.popped;
            var read = look.free.length + look.iced.length;
            if (read > expected) { expected = read; }
            if (look.iced.length > 0) { iced = look.iced; }
            var failed = false;
            if (drawn !== null) {
                var froze = look.iced.length - drawnOverIced;
                failed = froze <= 0 && elsaChainStays(drawn, look.free) >= cfg.chainStaysMin;
                if (failed) {
                    dead = dead.concat(drawn);
                    deadChains++;
                    elsaNoteMixed(this, drawnKind);
                    starvedRun++;
                } else if (froze < cfg.chainFreezeMin) {
                    fruitlessChains++;
                    starvedRun++;
                } else {
                    starvedRun = 0;
                }
                drawn = null;
            }
            var live = elsaWithoutDead(look.free, dead);
            var pick = elsaRowChain(live, look.obstacles, look.iced);
            var hidden = pick !== null && look.iced.length >= cfg.frozenIceMin
                && read < cfg.hiddenIceFraction * expected && look.free.length <= cfg.hiddenIceFreeMax;
            // debug(`[Elsa] pass`, {
            //     atMs: Date.now() - t0, free: look.free.length, iced: look.iced.length,
            //     waits: look.waits, pops: look.pops, popped: look.popped, bubbles: this.gameBubbles.length,
            //     failed: failed, row: pick === null ? -1 : pick.row,
            //     chainLen: pick === null ? 0 : pick.path.length, hop: pick === null ? 0 : pick.hop,
            //     hidden: hidden, overlap: pick === null ? 0 : pick.overlap
            // });
            var value = elsaBoardValue(this);
            dimRun = (value !== null && value < cfg.dimValueMax) ? dimRun + 1 : 0;
            if (dimRun >= 2) {
                log('[Elsa] round over (dim)', {atMs: Date.now() - t0, looks: looks, dim: Math.round(value)});
                roundOver = true;
                break;
            }
            if ((pick === null || starvedRun > 0) && Date.now() - roundCheckedAt >= cfg.roundCheckMs) {
                roundCheckedAt = Date.now();
                if (this.elsaRoundOver()) {
                    log('[Elsa] round over', {atMs: Date.now() - t0, looks: looks});
                    roundOver = true;
                    break;
                }
            }
            if (!salvoDone && (salvos > 0 || look.iced.length <= cfg.salvoMaxIced)
                && chainBy - Date.now() > cfg.salvoMinLeftMs) {
                var salvo = elsaSalvo(live, look.obstacles);
                if (salvo.length > 0) {
                    for (var sk = 0; sk < salvo.length; sk++) { this.linkTsums(salvo[sk]); }
                    salvos++;
                    // debug('[Elsa] salvo', {
                    //     atMs: Date.now() - t0, salvo: salvos, iced: look.iced.length,
                    //     chains: salvo.map(function(p) { return p.length; })
                    // });
                    salvoDone = salvos >= cfg.salvos;
                    salvoChains += salvo.length;
                    chains += salvo.length;
                    drawn = null;
                    starvedRun = 0;
                    this.sleep(cfg.iceFormMs);
                    continue;
                }
                if (salvos > 0) { salvoDone = true; }
            }
            if (pick === null || hidden) {
                starved++;
                starvedRun = hidden ? Math.max(starvedRun + 1, cfg.refreezeStarvedLooks) : starvedRun + 1;
                if (starvedRun >= cfg.refreezeStarvedLooks && look.iced.length >= cfg.refreezeMinIced
                    && chainBy - Date.now() > cfg.refreezeMinWindowLeftMs) {
                    aimedTaps += this.elsaBurstFrozen(look.iced);
                    bursts++;
                    this.sleep(elsaPostBurstSettleMs(look.iced.length));
                    iced = [];
                    starvedRun = 0;
                    dead = [];
                    continue;
                }
                this.sleepUntil(Math.min(Date.now() + cfg.rescanIdleMs, chainBy));
                continue;
            }
            var kindColour = this.boardClusters[+pick.path[0].tsumIdx];
            var path = pick.path;
            var kindRead = false;
            if (cfg.kind.on && elsaIsMixed(this, kindColour)) {
                var ea = pick.path[0], eb = pick.path[pick.path.length - 1];
                var head = eb.y > ea.y ? eb : ea;
                var top = pick.top - cfg.rowTolerance, bottom = pick.bottom + cfg.rowTolerance;
                var pool = live.filter(function(p) {
                    return p.tsumIdx === head.tsumIdx && p.y >= top && p.y <= bottom;
                });
                var got = elsaKindChain(this, head, pool, look.obstacles);
                // debug('[Elsa] kind', {
                //     atMs: Date.now() - t0, planned: pick.path.length,
                //     chainLen: got.path === null ? 0 : got.path.length,
                //     pool: got.pool, kept: got.kept, drops: got.drops, ms: got.ms
                // });
                elsaKindVerdict(this, kindColour, got.kept < got.drops.length);
                kindRead = true;
                if (got.path === null) {
                    kindLifts++;
                    dead = dead.concat(pick.path);
                    continue;
                }
                kindChains++;
                path = got.path;
            } else {
                this.linkTsums(pick.path);
            }
            drawn = path;
            drawnKind = kindRead ? undefined : kindColour;
            drawnOverIced = look.iced.length;
            chains++;
            this.sleep(cfg.iceFormMs);
        }
        if (this.isRunning && !roundOver && this.elsaRoundOver()) {
            log('[Elsa] round over', {atMs: Date.now() - t0, looks: looks});
            roundOver = true;
        }
        if (this.isRunning && !roundOver) {
            var last = this.elsaLook(Date.now(), expected);
            looks++;
            bubblesPopped += last.popped;
            if (last.iced.length > 0) { iced = last.iced; }
            aimedTaps += this.elsaBurstFrozen(iced);
            bursts++;
            this.sleep(elsaPostBurstSettleMs(iced.length));
            this.scanBoardQuick();
            this.popGameBubbles();
            this.sleepUntil(closesAt);
        }
        log('[Elsa] done', {
            skillLevel: level, windowMs: windowMs, looks: looks, chains: chains,
            starvedLooks: starved, deadChains: deadChains, fruitlessChains: fruitlessChains,
            bursts: bursts, icedLast: iced.length, aimedTaps: aimedTaps,
            roundOver: roundOver, bubblesPopped: bubblesPopped,
            salvos: salvos, salvoChains: salvoChains,
            kindChains: kindChains, kindLifts: kindLifts,
            totalMs: Date.now() - t0
        });
        } finally {
            this.tsumCount = savedTsumCount;
        }
  };